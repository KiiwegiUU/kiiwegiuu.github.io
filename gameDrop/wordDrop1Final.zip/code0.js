gdjs.gameIntroCode = {};
gdjs.gameIntroCode.localVariables = [];
gdjs.gameIntroCode.GDgameTileObjects2_1final = [];

gdjs.gameIntroCode.forEachIndex2 = 0;

gdjs.gameIntroCode.forEachObjects2 = [];

gdjs.gameIntroCode.forEachTemporary2 = null;

gdjs.gameIntroCode.forEachTotalCount2 = 0;

gdjs.gameIntroCode.GDovalObjects1= [];
gdjs.gameIntroCode.GDovalObjects2= [];
gdjs.gameIntroCode.GDovalObjects3= [];
gdjs.gameIntroCode.GDovalObjects4= [];
gdjs.gameIntroCode.GDovalObjects5= [];
gdjs.gameIntroCode.GDcircleObjects1= [];
gdjs.gameIntroCode.GDcircleObjects2= [];
gdjs.gameIntroCode.GDcircleObjects3= [];
gdjs.gameIntroCode.GDcircleObjects4= [];
gdjs.gameIntroCode.GDcircleObjects5= [];
gdjs.gameIntroCode.GDforwardButtonObjects1= [];
gdjs.gameIntroCode.GDforwardButtonObjects2= [];
gdjs.gameIntroCode.GDforwardButtonObjects3= [];
gdjs.gameIntroCode.GDforwardButtonObjects4= [];
gdjs.gameIntroCode.GDforwardButtonObjects5= [];
gdjs.gameIntroCode.GDgameTileObjects1= [];
gdjs.gameIntroCode.GDgameTileObjects2= [];
gdjs.gameIntroCode.GDgameTileObjects3= [];
gdjs.gameIntroCode.GDgameTileObjects4= [];
gdjs.gameIntroCode.GDgameTileObjects5= [];
gdjs.gameIntroCode.GDsplatObjects1= [];
gdjs.gameIntroCode.GDsplatObjects2= [];
gdjs.gameIntroCode.GDsplatObjects3= [];
gdjs.gameIntroCode.GDsplatObjects4= [];
gdjs.gameIntroCode.GDsplatObjects5= [];
gdjs.gameIntroCode.GDincorrectAnswerObjects1= [];
gdjs.gameIntroCode.GDincorrectAnswerObjects2= [];
gdjs.gameIntroCode.GDincorrectAnswerObjects3= [];
gdjs.gameIntroCode.GDincorrectAnswerObjects4= [];
gdjs.gameIntroCode.GDincorrectAnswerObjects5= [];
gdjs.gameIntroCode.GDfooterObjects1= [];
gdjs.gameIntroCode.GDfooterObjects2= [];
gdjs.gameIntroCode.GDfooterObjects3= [];
gdjs.gameIntroCode.GDfooterObjects4= [];
gdjs.gameIntroCode.GDfooterObjects5= [];
gdjs.gameIntroCode.GDbackgroundObjects1= [];
gdjs.gameIntroCode.GDbackgroundObjects2= [];
gdjs.gameIntroCode.GDbackgroundObjects3= [];
gdjs.gameIntroCode.GDbackgroundObjects4= [];
gdjs.gameIntroCode.GDbackgroundObjects5= [];
gdjs.gameIntroCode.GDbackButtonObjects1= [];
gdjs.gameIntroCode.GDbackButtonObjects2= [];
gdjs.gameIntroCode.GDbackButtonObjects3= [];
gdjs.gameIntroCode.GDbackButtonObjects4= [];
gdjs.gameIntroCode.GDbackButtonObjects5= [];
gdjs.gameIntroCode.GDpauseButtonObjects1= [];
gdjs.gameIntroCode.GDpauseButtonObjects2= [];
gdjs.gameIntroCode.GDpauseButtonObjects3= [];
gdjs.gameIntroCode.GDpauseButtonObjects4= [];
gdjs.gameIntroCode.GDpauseButtonObjects5= [];
gdjs.gameIntroCode.GDstarHolderObjects1= [];
gdjs.gameIntroCode.GDstarHolderObjects2= [];
gdjs.gameIntroCode.GDstarHolderObjects3= [];
gdjs.gameIntroCode.GDstarHolderObjects4= [];
gdjs.gameIntroCode.GDstarHolderObjects5= [];
gdjs.gameIntroCode.GDstar1Objects1= [];
gdjs.gameIntroCode.GDstar1Objects2= [];
gdjs.gameIntroCode.GDstar1Objects3= [];
gdjs.gameIntroCode.GDstar1Objects4= [];
gdjs.gameIntroCode.GDstar1Objects5= [];
gdjs.gameIntroCode.GDstar2Objects1= [];
gdjs.gameIntroCode.GDstar2Objects2= [];
gdjs.gameIntroCode.GDstar2Objects3= [];
gdjs.gameIntroCode.GDstar2Objects4= [];
gdjs.gameIntroCode.GDstar2Objects5= [];
gdjs.gameIntroCode.GDstar3Objects1= [];
gdjs.gameIntroCode.GDstar3Objects2= [];
gdjs.gameIntroCode.GDstar3Objects3= [];
gdjs.gameIntroCode.GDstar3Objects4= [];
gdjs.gameIntroCode.GDstar3Objects5= [];
gdjs.gameIntroCode.GDcorrectWordTextObjects1= [];
gdjs.gameIntroCode.GDcorrectWordTextObjects2= [];
gdjs.gameIntroCode.GDcorrectWordTextObjects3= [];
gdjs.gameIntroCode.GDcorrectWordTextObjects4= [];
gdjs.gameIntroCode.GDcorrectWordTextObjects5= [];
gdjs.gameIntroCode.GDanswersNeededTextObjects1= [];
gdjs.gameIntroCode.GDanswersNeededTextObjects2= [];
gdjs.gameIntroCode.GDanswersNeededTextObjects3= [];
gdjs.gameIntroCode.GDanswersNeededTextObjects4= [];
gdjs.gameIntroCode.GDanswersNeededTextObjects5= [];
gdjs.gameIntroCode.GDpauseWordObjects1= [];
gdjs.gameIntroCode.GDpauseWordObjects2= [];
gdjs.gameIntroCode.GDpauseWordObjects3= [];
gdjs.gameIntroCode.GDpauseWordObjects4= [];
gdjs.gameIntroCode.GDpauseWordObjects5= [];
gdjs.gameIntroCode.GDPauseScreenObjects1= [];
gdjs.gameIntroCode.GDPauseScreenObjects2= [];
gdjs.gameIntroCode.GDPauseScreenObjects3= [];
gdjs.gameIntroCode.GDPauseScreenObjects4= [];
gdjs.gameIntroCode.GDPauseScreenObjects5= [];
gdjs.gameIntroCode.GDCloudObjects1= [];
gdjs.gameIntroCode.GDCloudObjects2= [];
gdjs.gameIntroCode.GDCloudObjects3= [];
gdjs.gameIntroCode.GDCloudObjects4= [];
gdjs.gameIntroCode.GDCloudObjects5= [];
gdjs.gameIntroCode.GDLevelSixTimeObjects1= [];
gdjs.gameIntroCode.GDLevelSixTimeObjects2= [];
gdjs.gameIntroCode.GDLevelSixTimeObjects3= [];
gdjs.gameIntroCode.GDLevelSixTimeObjects4= [];
gdjs.gameIntroCode.GDLevelSixTimeObjects5= [];
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects1= [];
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects2= [];
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects3= [];
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects4= [];
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects5= [];
gdjs.gameIntroCode.GDquestionMarkObjects1= [];
gdjs.gameIntroCode.GDquestionMarkObjects2= [];
gdjs.gameIntroCode.GDquestionMarkObjects3= [];
gdjs.gameIntroCode.GDquestionMarkObjects4= [];
gdjs.gameIntroCode.GDquestionMarkObjects5= [];


gdjs.gameIntroCode.eventsList0 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "generationRateIncreaser");
}{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(gdjs.randomInRange(8, 10));
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "generationRateIncreaser") >= 10;
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber() / 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "generationRateIncreaser");
}}

}


};gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects2Objects = Hashtable.newFrom({"gameTile": gdjs.gameIntroCode.GDgameTileObjects2});
gdjs.gameIntroCode.eventsList1 = function(runtimeScene) {

};gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects1Objects = Hashtable.newFrom({"gameTile": gdjs.gameIntroCode.GDgameTileObjects1});
gdjs.gameIntroCode.eventsList2 = function(runtimeScene) {

{



}


{



}


{


let stopDoWhile_0 = false;
do {
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber() == runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
if (isConditionTrue_0) {
let isConditionTrue_0 = false;
if (true) {
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(gdjs.randomInRange(0, runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber()));
}
{ //Subevents: 
gdjs.gameIntroCode.eventsList1(runtimeScene);} //Subevents end.
}
} else stopDoWhile_0 = true; 
} while (!stopDoWhile_0);

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber() == runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
if (isConditionTrue_0) {
gdjs.gameIntroCode.GDgameTileObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects1Objects, gdjs.randomInRange(0, 532), -(188), "");
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects1.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects1[i].returnVariable(gdjs.gameIntroCode.GDgameTileObjects1[i].getVariables().getFromIndex(1)).setNumber(gdjs.gameIntroCode.GDgameTileObjects1[i].getVariables().getFromIndex(1).getAsNumber() + 1);
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects1.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects1[i].getBehavior("Animation").setAnimationIndex(runtimeScene.getGame().getVariables().getFromIndex(13).getAsNumber());
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects1.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects1[i].getBehavior("Physics2").setGravityScale(gdjs.randomInRange(runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber()));
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "incorrectAnswerGenTimer");
}}

}


};gdjs.gameIntroCode.eventsList3 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("correctWordText"), gdjs.gameIntroCode.GDcorrectWordTextObjects2);
gdjs.gameIntroCode.GDgameTileObjects2.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "incorrectAnswerGenTimer");
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(0, runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber()));
}{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}{for(var i = 0, len = gdjs.gameIntroCode.GDcorrectWordTextObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDcorrectWordTextObjects2[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber()).getAsString());
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects2Objects, gdjs.randomInRange(0, 532), 100, "");
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].returnVariable(gdjs.gameIntroCode.GDgameTileObjects2[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].getBehavior("Animation").setAnimationIndex(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].getBehavior("Physics2").setGravityScale(runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber());
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "incorrectAnswerGenTimer") >= runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber();
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(13).setNumber(gdjs.randomInRange(0, runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber()));
}
{ //Subevents
gdjs.gameIntroCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.gameIntroCode.eventsList4 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects2);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gravityScaleTimer");
}{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(0.003);
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(0.0035);
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].getBehavior("Physics2").setGravityScale(gdjs.randomInRange(runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber()));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "gravityScaleTimer") >= 90;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber() <= 0.0065);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(10).setNumber(runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber() + 0.0005);
}{runtimeScene.getGame().getVariables().getFromIndex(11).setNumber(runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber() + 0.0005);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gravityScaleTimer");
}}

}


};gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects3Objects = Hashtable.newFrom({"gameTile": gdjs.gameIntroCode.GDgameTileObjects3});
gdjs.gameIntroCode.asyncCallback14510780 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("correctWordText"), gdjs.gameIntroCode.GDcorrectWordTextObjects3);
gdjs.copyArray(asyncObjectsList.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects3);

{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(0, runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber()));
}{for(var i = 0, len = gdjs.gameIntroCode.GDcorrectWordTextObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDcorrectWordTextObjects3[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber()).getAsString());
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects3Objects, gdjs.randomInRange(0, 532), -(188), "");
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects3[i].returnVariable(gdjs.gameIntroCode.GDgameTileObjects3[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects3[i].getBehavior("Animation").setAnimationIndex(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).setBoolean(false);
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects3[i].getBehavior("Physics2").setGravityScale(gdjs.randomInRange(runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber()));
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() + 1);
}{runtimeScene.getGame().getVariables().getFromIndex(17).setNumber(runtimeScene.getGame().getVariables().getFromIndex(17).getAsNumber() + 1);
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
for (const obj of gdjs.gameIntroCode.GDgameTileObjects2) asyncObjectsList.addObject("gameTile", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14510780(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects2Objects = Hashtable.newFrom({"gameTile": gdjs.gameIntroCode.GDgameTileObjects2});
gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDfooterObjects2Objects = Hashtable.newFrom({"footer": gdjs.gameIntroCode.GDfooterObjects2});
gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDsplatObjects2Objects = Hashtable.newFrom({"splat": gdjs.gameIntroCode.GDsplatObjects2});
gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects3Objects = Hashtable.newFrom({"gameTile": gdjs.gameIntroCode.GDgameTileObjects3});
gdjs.gameIntroCode.asyncCallback14516684 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("correctWordText"), gdjs.gameIntroCode.GDcorrectWordTextObjects3);
gdjs.copyArray(asyncObjectsList.getObjects("splat"), gdjs.gameIntroCode.GDsplatObjects3);

gdjs.copyArray(asyncObjectsList.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects3);

{for(var i = 0, len = gdjs.gameIntroCode.GDsplatObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDsplatObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(0, runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber()));
}{for(var i = 0, len = gdjs.gameIntroCode.GDcorrectWordTextObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDcorrectWordTextObjects3[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(1).getChild(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber()).getAsString());
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects3Objects, gdjs.randomInRange(0, 532), -(188), "");
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects3[i].returnVariable(gdjs.gameIntroCode.GDgameTileObjects3[i].getVariables().getFromIndex(0)).setBoolean(true);
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects3[i].getBehavior("Animation").setAnimationIndex(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
}{runtimeScene.getGame().getVariables().getFromIndex(8).setBoolean(false);
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects3[i].getBehavior("Physics2").setGravityScale(gdjs.randomInRange(runtimeScene.getGame().getVariables().getFromIndex(10).getAsNumber(), runtimeScene.getGame().getVariables().getFromIndex(11).getAsNumber()));
}
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
for (const obj of gdjs.gameIntroCode.GDgameTileObjects2) asyncObjectsList.addObject("gameTile", obj);
for (const obj of gdjs.gameIntroCode.GDsplatObjects2) asyncObjectsList.addObject("splat", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14516684(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects2Objects = Hashtable.newFrom({"gameTile": gdjs.gameIntroCode.GDgameTileObjects2});
gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDfooterObjects2Objects = Hashtable.newFrom({"footer": gdjs.gameIntroCode.GDfooterObjects2});
gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDsplatObjects2Objects = Hashtable.newFrom({"splat": gdjs.gameIntroCode.GDsplatObjects2});
gdjs.gameIntroCode.asyncCallback14522004 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("splat"), gdjs.gameIntroCode.GDsplatObjects3);

{runtimeScene.getGame().getVariables().getFromIndex(8).setBoolean(false);
}{for(var i = 0, len = gdjs.gameIntroCode.GDsplatObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDsplatObjects3[i].deleteFromScene(runtimeScene);
}
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
for (const obj of gdjs.gameIntroCode.GDsplatObjects2) asyncObjectsList.addObject("splat", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14522004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects1Objects = Hashtable.newFrom({"gameTile": gdjs.gameIntroCode.GDgameTileObjects1});
gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDfooterObjects1Objects = Hashtable.newFrom({"footer": gdjs.gameIntroCode.GDfooterObjects1});
gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDsplatObjects1Objects = Hashtable.newFrom({"splat": gdjs.gameIntroCode.GDsplatObjects1});
gdjs.gameIntroCode.asyncCallback14524988 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("splat"), gdjs.gameIntroCode.GDsplatObjects2);

{runtimeScene.getGame().getVariables().getFromIndex(8).setBoolean(false);
}{for(var i = 0, len = gdjs.gameIntroCode.GDsplatObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDsplatObjects2[i].deleteFromScene(runtimeScene);
}
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
for (const obj of gdjs.gameIntroCode.GDsplatObjects1) asyncObjectsList.addObject("splat", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14524988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.eventsList9 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameIntroCode.GDgameTileObjects2.length;i<l;++i) {
    if ( gdjs.gameIntroCode.GDgameTileObjects2[i].getBehavior("Animation").getAnimationIndex() == runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.gameIntroCode.GDgameTileObjects2[k] = gdjs.gameIntroCode.GDgameTileObjects2[i];
        ++k;
    }
}
gdjs.gameIntroCode.GDgameTileObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(18).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 3);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("circle"), gdjs.gameIntroCode.GDcircleObjects2);
/* Reuse gdjs.gameIntroCode.GDgameTileObjects2 */
{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].returnVariable(gdjs.gameIntroCode.GDgameTileObjects2[i].getVariables().getFromIndex(0)).setBoolean(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "correct.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(4);
}{for(var i = 0, len = gdjs.gameIntroCode.GDcircleObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDcircleObjects2[i].hide();
}
}
{ //Subevents
gdjs.gameIntroCode.eventsList5(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("footer"), gdjs.gameIntroCode.GDfooterObjects2);
gdjs.copyArray(runtimeScene.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.areObjectsColliding(gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects2Objects, "Physics2", gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDfooterObjects2Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameIntroCode.GDgameTileObjects2.length;i<l;++i) {
    if ( gdjs.gameIntroCode.GDgameTileObjects2[i].getVariableBoolean(gdjs.gameIntroCode.GDgameTileObjects2[i].getVariables().getFromIndex(0), true, false) ) {
        isConditionTrue_0 = true;
        gdjs.gameIntroCode.GDgameTileObjects2[k] = gdjs.gameIntroCode.GDgameTileObjects2[i];
        ++k;
    }
}
gdjs.gameIntroCode.GDgameTileObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(8).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameIntroCode.GDgameTileObjects2.length;i<l;++i) {
    if ( gdjs.gameIntroCode.GDgameTileObjects2[i].getBehavior("Animation").getAnimationIndex() == runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.gameIntroCode.GDgameTileObjects2[k] = gdjs.gameIntroCode.GDgameTileObjects2[i];
        ++k;
    }
}
gdjs.gameIntroCode.GDgameTileObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(18).getAsBoolean();
}
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameIntroCode.GDgameTileObjects2 */
gdjs.gameIntroCode.GDsplatObjects2.length = 0;

{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].returnVariable(gdjs.gameIntroCode.GDgameTileObjects2[i].getVariables().getFromIndex(0)).setBoolean(false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() + 1);
}{runtimeScene.getGame().getVariables().getFromIndex(8).setBoolean(true);
}{gdjs.evtTools.sound.playSound(runtimeScene, "sandExplosion.mp3", false, 100, 1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.4, 0.2, 0.2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDsplatObjects2Objects, (( gdjs.gameIntroCode.GDgameTileObjects2.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects2[0].getPointX("")), (( gdjs.gameIntroCode.GDgameTileObjects2.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.gameIntroCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("footer"), gdjs.gameIntroCode.GDfooterObjects2);
gdjs.copyArray(runtimeScene.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.areObjectsColliding(gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects2Objects, "Physics2", gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDfooterObjects2Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameIntroCode.GDgameTileObjects2.length;i<l;++i) {
    if ( gdjs.gameIntroCode.GDgameTileObjects2[i].getVariableBoolean(gdjs.gameIntroCode.GDgameTileObjects2[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.gameIntroCode.GDgameTileObjects2[k] = gdjs.gameIntroCode.GDgameTileObjects2[i];
        ++k;
    }
}
gdjs.gameIntroCode.GDgameTileObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(8).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameIntroCode.GDgameTileObjects2.length;i<l;++i) {
    if ( gdjs.gameIntroCode.GDgameTileObjects2[i].getBehavior("Animation").getAnimationIndex() == runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.gameIntroCode.GDgameTileObjects2[k] = gdjs.gameIntroCode.GDgameTileObjects2[i];
        ++k;
    }
}
gdjs.gameIntroCode.GDgameTileObjects2.length = k;
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameIntroCode.GDgameTileObjects2 */
gdjs.gameIntroCode.GDsplatObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(8).setBoolean(true);
}{gdjs.evtTools.sound.playSound(runtimeScene, "sandExplosion.mp3", false, 100, 1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.4, 0.2, 0.2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDsplatObjects2Objects, (( gdjs.gameIntroCode.GDgameTileObjects2.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects2[0].getPointX("")), (( gdjs.gameIntroCode.GDgameTileObjects2.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.gameIntroCode.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("footer"), gdjs.gameIntroCode.GDfooterObjects1);
gdjs.copyArray(runtimeScene.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.physics2.areObjectsColliding(gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDgameTileObjects1Objects, "Physics2", gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDfooterObjects1Objects, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(8).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameIntroCode.GDgameTileObjects1.length;i<l;++i) {
    if ( !(gdjs.gameIntroCode.GDgameTileObjects1[i].getBehavior("Animation").getAnimationIndex() == runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber()) ) {
        isConditionTrue_0 = true;
        gdjs.gameIntroCode.GDgameTileObjects1[k] = gdjs.gameIntroCode.GDgameTileObjects1[i];
        ++k;
    }
}
gdjs.gameIntroCode.GDgameTileObjects1.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameIntroCode.GDgameTileObjects1 */
gdjs.gameIntroCode.GDsplatObjects1.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(8).setBoolean(true);
}{gdjs.evtTools.sound.playSound(runtimeScene, "sandExplosion.mp3", false, 100, 1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.4, 0.2, 0.2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDsplatObjects1Objects, (( gdjs.gameIntroCode.GDgameTileObjects1.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects1[0].getPointX("")), (( gdjs.gameIntroCode.GDgameTileObjects1.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects1.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.gameIntroCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.gameIntroCode.eventsList10 = function(runtimeScene) {

{

gdjs.gameIntroCode.GDgameTileObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.gameIntroCode.GDgameTileObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects3);
for (var i = 0, k = 0, l = gdjs.gameIntroCode.GDgameTileObjects3.length;i<l;++i) {
    if ( gdjs.gameIntroCode.GDgameTileObjects3[i].getX() > 532 ) {
        isConditionTrue_1 = true;
        gdjs.gameIntroCode.GDgameTileObjects3[k] = gdjs.gameIntroCode.GDgameTileObjects3[i];
        ++k;
    }
}
gdjs.gameIntroCode.GDgameTileObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameIntroCode.GDgameTileObjects3.length; j < jLen ; ++j) {
        if ( gdjs.gameIntroCode.GDgameTileObjects2_1final.indexOf(gdjs.gameIntroCode.GDgameTileObjects3[j]) === -1 )
            gdjs.gameIntroCode.GDgameTileObjects2_1final.push(gdjs.gameIntroCode.GDgameTileObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects3);
for (var i = 0, k = 0, l = gdjs.gameIntroCode.GDgameTileObjects3.length;i<l;++i) {
    if ( gdjs.gameIntroCode.GDgameTileObjects3[i].getX() < 0 ) {
        isConditionTrue_1 = true;
        gdjs.gameIntroCode.GDgameTileObjects3[k] = gdjs.gameIntroCode.GDgameTileObjects3[i];
        ++k;
    }
}
gdjs.gameIntroCode.GDgameTileObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.gameIntroCode.GDgameTileObjects3.length; j < jLen ; ++j) {
        if ( gdjs.gameIntroCode.GDgameTileObjects2_1final.indexOf(gdjs.gameIntroCode.GDgameTileObjects3[j]) === -1 )
            gdjs.gameIntroCode.GDgameTileObjects2_1final.push(gdjs.gameIntroCode.GDgameTileObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.gameIntroCode.GDgameTileObjects2_1final, gdjs.gameIntroCode.GDgameTileObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.gameIntroCode.GDgameTileObjects2 */
{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].setPosition(gdjs.randomInRange(0, 532),-(188));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(19).setString("Level 1");
}{runtimeScene.getGame().getVariables().getFromIndex(21).setString("levelTwo");
}{runtimeScene.getGame().getVariables().getFromIndex(20).setString("levelOne");
}}

}


{



}


{



}


{



}


};gdjs.gameIntroCode.eventsList11 = function(runtimeScene) {

};gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDsplatObjects4Objects = Hashtable.newFrom({"splat": gdjs.gameIntroCode.GDsplatObjects4});
gdjs.gameIntroCode.asyncCallback14534332 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("splat"), gdjs.gameIntroCode.GDsplatObjects5);

{for(var i = 0, len = gdjs.gameIntroCode.GDsplatObjects5.length ;i < len;++i) {
    gdjs.gameIntroCode.GDsplatObjects5[i].deleteFromScene(runtimeScene);
}
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
for (const obj of gdjs.gameIntroCode.GDsplatObjects4) asyncObjectsList.addObject("splat", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14534332(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.asyncCallback14533452 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects4);

gdjs.gameIntroCode.GDsplatObjects4.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "sandExplosion.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects4.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects4[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.4, 0.2, 0.2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDsplatObjects4Objects, (( gdjs.gameIntroCode.GDgameTileObjects4.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects4[0].getPointX("")), (( gdjs.gameIntroCode.GDgameTileObjects4.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects4[0].getPointY("")), "");
}
{ //Subevents
gdjs.gameIntroCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.gameIntroCode.GDgameTileObjects2, gdjs.gameIntroCode.GDgameTileObjects3);


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
for (const obj of gdjs.gameIntroCode.GDgameTileObjects3) asyncObjectsList.addObject("gameTile", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait((1070 - (( gdjs.gameIntroCode.GDgameTileObjects3.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects3[0].getPointY(""))) / 2140), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14533452(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects1);

for (gdjs.gameIntroCode.forEachIndex2 = 0;gdjs.gameIntroCode.forEachIndex2 < gdjs.gameIntroCode.GDgameTileObjects1.length;++gdjs.gameIntroCode.forEachIndex2) {
gdjs.gameIntroCode.GDgameTileObjects2.length = 0;


gdjs.gameIntroCode.forEachTemporary2 = gdjs.gameIntroCode.GDgameTileObjects1[gdjs.gameIntroCode.forEachIndex2];
gdjs.gameIntroCode.GDgameTileObjects2.push(gdjs.gameIntroCode.forEachTemporary2);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameIntroCode.GDgameTileObjects2.length;i<l;++i) {
    if ( gdjs.gameIntroCode.GDgameTileObjects2[i].getVariableNumber(gdjs.gameIntroCode.GDgameTileObjects2[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.gameIntroCode.GDgameTileObjects2[k] = gdjs.gameIntroCode.GDgameTileObjects2[i];
        ++k;
    }
}
gdjs.gameIntroCode.GDgameTileObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 7);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(18).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.gameIntroCode.GDgameTileObjects2.length;i<l;++i) {
    if ( gdjs.gameIntroCode.GDgameTileObjects2[i].getBehavior("Animation").getAnimationIndex() != runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.gameIntroCode.GDgameTileObjects2[k] = gdjs.gameIntroCode.GDgameTileObjects2[i];
        ++k;
    }
}
gdjs.gameIntroCode.GDgameTileObjects2.length = k;
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(8);
}{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() + 1);
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].activateBehavior("Physics2", false);
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDgameTileObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDgameTileObjects2[i].getBehavior("Tween").addObjectPositionYTween2("incorrectSlam", 1070, "linear", (1070 - (gdjs.gameIntroCode.GDgameTileObjects2[i].getPointY(""))) / 2140, false);
}
}
{ //Subevents: 
gdjs.gameIntroCode.eventsList13(runtimeScene);} //Subevents end.
}
}

}


};gdjs.gameIntroCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star3"), gdjs.gameIntroCode.GDstar3Objects2);
{for(var i = 0, len = gdjs.gameIntroCode.GDstar3Objects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDstar3Objects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star2"), gdjs.gameIntroCode.GDstar2Objects2);
{for(var i = 0, len = gdjs.gameIntroCode.GDstar2Objects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDstar2Objects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() == 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star1"), gdjs.gameIntroCode.GDstar1Objects1);
{for(var i = 0, len = gdjs.gameIntroCode.GDstar1Objects1.length ;i < len;++i) {
    gdjs.gameIntroCode.GDstar1Objects1[i].hide();
}
}}

}


};gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDbackButtonObjects2Objects = Hashtable.newFrom({"backButton": gdjs.gameIntroCode.GDbackButtonObjects2});
gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDpauseButtonObjects2Objects = Hashtable.newFrom({"pauseButton": gdjs.gameIntroCode.GDpauseButtonObjects2});
gdjs.gameIntroCode.eventsList16 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PauseScreen"), gdjs.gameIntroCode.GDPauseScreenObjects2);
gdjs.copyArray(runtimeScene.getObjects("pauseWord"), gdjs.gameIntroCode.GDpauseWordObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(16).setNumber(6);
}{runtimeScene.getGame().getVariables().getFromIndex(17).setNumber(0);
}{for(var i = 0, len = gdjs.gameIntroCode.GDPauseScreenObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDPauseScreenObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDpauseWordObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDpauseWordObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDPauseScreenObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDPauseScreenObjects2[i].getBehavior("Opacity").setOpacity(130);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("answersNeededText"), gdjs.gameIntroCode.GDanswersNeededTextObjects2);
{for(var i = 0, len = gdjs.gameIntroCode.GDanswersNeededTextObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDanswersNeededTextObjects2[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(17).getAsString() + "/" + runtimeScene.getGame().getVariables().getFromIndex(16).getAsString());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.gameIntroCode.GDbackButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDbackButtonObjects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelMenuScreen", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("pauseButton"), gdjs.gameIntroCode.GDpauseButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDpauseButtonObjects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(18));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(18).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PauseScreen"), gdjs.gameIntroCode.GDPauseScreenObjects2);
gdjs.copyArray(runtimeScene.getObjects("pauseWord"), gdjs.gameIntroCode.GDpauseWordObjects2);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{for(var i = 0, len = gdjs.gameIntroCode.GDpauseWordObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDpauseWordObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDPauseScreenObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDPauseScreenObjects2[i].hide(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(18).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("PauseScreen"), gdjs.gameIntroCode.GDPauseScreenObjects1);
gdjs.copyArray(runtimeScene.getObjects("pauseWord"), gdjs.gameIntroCode.GDpauseWordObjects1);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}{for(var i = 0, len = gdjs.gameIntroCode.GDpauseWordObjects1.length ;i < len;++i) {
    gdjs.gameIntroCode.GDpauseWordObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDPauseScreenObjects1.length ;i < len;++i) {
    gdjs.gameIntroCode.GDPauseScreenObjects1[i].hide();
}
}}

}


};gdjs.gameIntroCode.asyncCallback14546340 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("oval"), gdjs.gameIntroCode.GDovalObjects4);

{for(var i = 0, len = gdjs.gameIntroCode.GDovalObjects4.length ;i < len;++i) {
    gdjs.gameIntroCode.GDovalObjects4[i].hide();
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(1);
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList17 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
for (const obj of gdjs.gameIntroCode.GDovalObjects3) asyncObjectsList.addObject("oval", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14546340(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.asyncCallback14547732 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("oval"), gdjs.gameIntroCode.GDovalObjects3);

{for(var i = 0, len = gdjs.gameIntroCode.GDovalObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDovalObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.gameIntroCode.eventsList17(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
for (const obj of gdjs.gameIntroCode.GDovalObjects2) asyncObjectsList.addObject("oval", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14547732(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.asyncCallback14550756 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("circle"), gdjs.gameIntroCode.GDcircleObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(2);
}{for(var i = 0, len = gdjs.gameIntroCode.GDcircleObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDcircleObjects3[i].hide(false);
}
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14550756(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.asyncCallback14551932 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(3);
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14551932(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.asyncCallback14552844 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("oval"), gdjs.gameIntroCode.GDovalObjects3);
{for(var i = 0, len = gdjs.gameIntroCode.GDovalObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDovalObjects3[i].hide(false);
}
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14552844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.asyncCallback14554564 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("oval"), gdjs.gameIntroCode.GDovalObjects3);
{for(var i = 0, len = gdjs.gameIntroCode.GDovalObjects3.length ;i < len;++i) {
    gdjs.gameIntroCode.GDovalObjects3[i].hide();
}
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14554564(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.asyncCallback14555948 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(7);
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList23 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(7), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14555948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.asyncCallback14558716 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(10);
}gdjs.gameIntroCode.localVariables.length = 0;
}
gdjs.gameIntroCode.eventsList24 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.gameIntroCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.gameIntroCode.asyncCallback14558716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDforwardButtonObjects2Objects = Hashtable.newFrom({"forwardButton": gdjs.gameIntroCode.GDforwardButtonObjects2});
gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDforwardButtonObjects2Objects = Hashtable.newFrom({"forwardButton": gdjs.gameIntroCode.GDforwardButtonObjects2});
gdjs.gameIntroCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "introViewed", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(39));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(39).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(40).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelMenuScreen", false);
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 0);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = !runtimeScene.getGame().getVariables().getFromIndex(39).getAsBoolean();
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = runtimeScene.getGame().getVariables().getFromIndex(40).getAsBoolean();
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = runtimeScene.getGame().getVariables().getFromIndex(39).getAsBoolean();
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = runtimeScene.getGame().getVariables().getFromIndex(40).getAsBoolean();
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
{isConditionTrue_2 = !runtimeScene.getGame().getVariables().getFromIndex(39).getAsBoolean();
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = !runtimeScene.getGame().getVariables().getFromIndex(40).getAsBoolean();
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("circle"), gdjs.gameIntroCode.GDcircleObjects2);
gdjs.copyArray(runtimeScene.getObjects("forwardButton"), gdjs.gameIntroCode.GDforwardButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("oval"), gdjs.gameIntroCode.GDovalObjects2);
{for(var i = 0, len = gdjs.gameIntroCode.GDforwardButtonObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDforwardButtonObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDovalObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDovalObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.gameIntroCode.GDcircleObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDcircleObjects2[i].hide();
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "g1.mp3", 0, false, 100, 1);
}
{ //Subevents
gdjs.gameIntroCode.eventsList18(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelStopped(runtimeScene, 0);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "g2.mp3", 0, false, 100, 1);
}
{ //Subevents
gdjs.gameIntroCode.eventsList19(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelStopped(runtimeScene, 0);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 2);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "g3.mp3", 0, false, 100, 1);
}
{ //Subevents
gdjs.gameIntroCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelStopped(runtimeScene, 0);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 4);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "g4.mp3", 0, false, 100, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(5);
}
{ //Subevents
gdjs.gameIntroCode.eventsList21(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelStopped(runtimeScene, 0);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 5);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "g5.mp3", 0, false, 100, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(6);
}
{ //Subevents
gdjs.gameIntroCode.eventsList22(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelStopped(runtimeScene, 0);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 6);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "g6.mp3", 0, false, 100, 1);
}
{ //Subevents
gdjs.gameIntroCode.eventsList23(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelStopped(runtimeScene, 0);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 8);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "g7.mp3", 0, false, 100, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(9);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelStopped(runtimeScene, 0);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 9);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "g8.mp3", 0, false, 100, 1);
}
{ //Subevents
gdjs.gameIntroCode.eventsList24(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.sound.isSoundOnChannelStopped(runtimeScene, 0);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 10);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("forwardButton"), gdjs.gameIntroCode.GDforwardButtonObjects2);
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "correct.mp3", 0, false, 100, 1);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(11);
}{for(var i = 0, len = gdjs.gameIntroCode.GDforwardButtonObjects2.length ;i < len;++i) {
    gdjs.gameIntroCode.GDforwardButtonObjects2[i].getBehavior("Tween").addObjectOpacityTween2("fadeIn", 255, "linear", 0.5, false);
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(12);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("forwardButton"), gdjs.gameIntroCode.GDforwardButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDforwardButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 12);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(39).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelOne", false);
}{runtimeScene.getGame().getVariables().getFromIndex(40).setBoolean(false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("forwardButton"), gdjs.gameIntroCode.GDforwardButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.gameIntroCode.mapOfGDgdjs_9546gameIntroCode_9546GDforwardButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() == 12);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(39).getAsBoolean();
}
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelMenuScreen", false);
}{runtimeScene.getGame().getVariables().getFromIndex(40).setBoolean(false);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("circle"), gdjs.gameIntroCode.GDcircleObjects1);
gdjs.copyArray(runtimeScene.getObjects("gameTile"), gdjs.gameIntroCode.GDgameTileObjects1);
{for(var i = 0, len = gdjs.gameIntroCode.GDcircleObjects1.length ;i < len;++i) {
    gdjs.gameIntroCode.GDcircleObjects1[i].setPosition((( gdjs.gameIntroCode.GDgameTileObjects1.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects1[0].getPointX("")),(( gdjs.gameIntroCode.GDgameTileObjects1.length === 0 ) ? 0 :gdjs.gameIntroCode.GDgameTileObjects1[0].getPointY("")));
}
}}

}


};gdjs.gameIntroCode.eventsList26 = function(runtimeScene) {

{



}


{


gdjs.gameIntroCode.eventsList0(runtimeScene);
}


{



}


{


gdjs.gameIntroCode.eventsList3(runtimeScene);
}


{



}


{


gdjs.gameIntroCode.eventsList4(runtimeScene);
}


{



}


{


gdjs.gameIntroCode.eventsList9(runtimeScene);
}


{



}


{


gdjs.gameIntroCode.eventsList10(runtimeScene);
}


{


gdjs.gameIntroCode.eventsList11(runtimeScene);
}


{


gdjs.gameIntroCode.eventsList14(runtimeScene);
}


{


gdjs.gameIntroCode.eventsList15(runtimeScene);
}


{



}


{


gdjs.gameIntroCode.eventsList16(runtimeScene);
}


{


gdjs.gameIntroCode.eventsList25(runtimeScene);
}


};

gdjs.gameIntroCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.gameIntroCode.GDovalObjects1.length = 0;
gdjs.gameIntroCode.GDovalObjects2.length = 0;
gdjs.gameIntroCode.GDovalObjects3.length = 0;
gdjs.gameIntroCode.GDovalObjects4.length = 0;
gdjs.gameIntroCode.GDovalObjects5.length = 0;
gdjs.gameIntroCode.GDcircleObjects1.length = 0;
gdjs.gameIntroCode.GDcircleObjects2.length = 0;
gdjs.gameIntroCode.GDcircleObjects3.length = 0;
gdjs.gameIntroCode.GDcircleObjects4.length = 0;
gdjs.gameIntroCode.GDcircleObjects5.length = 0;
gdjs.gameIntroCode.GDforwardButtonObjects1.length = 0;
gdjs.gameIntroCode.GDforwardButtonObjects2.length = 0;
gdjs.gameIntroCode.GDforwardButtonObjects3.length = 0;
gdjs.gameIntroCode.GDforwardButtonObjects4.length = 0;
gdjs.gameIntroCode.GDforwardButtonObjects5.length = 0;
gdjs.gameIntroCode.GDgameTileObjects1.length = 0;
gdjs.gameIntroCode.GDgameTileObjects2.length = 0;
gdjs.gameIntroCode.GDgameTileObjects3.length = 0;
gdjs.gameIntroCode.GDgameTileObjects4.length = 0;
gdjs.gameIntroCode.GDgameTileObjects5.length = 0;
gdjs.gameIntroCode.GDsplatObjects1.length = 0;
gdjs.gameIntroCode.GDsplatObjects2.length = 0;
gdjs.gameIntroCode.GDsplatObjects3.length = 0;
gdjs.gameIntroCode.GDsplatObjects4.length = 0;
gdjs.gameIntroCode.GDsplatObjects5.length = 0;
gdjs.gameIntroCode.GDincorrectAnswerObjects1.length = 0;
gdjs.gameIntroCode.GDincorrectAnswerObjects2.length = 0;
gdjs.gameIntroCode.GDincorrectAnswerObjects3.length = 0;
gdjs.gameIntroCode.GDincorrectAnswerObjects4.length = 0;
gdjs.gameIntroCode.GDincorrectAnswerObjects5.length = 0;
gdjs.gameIntroCode.GDfooterObjects1.length = 0;
gdjs.gameIntroCode.GDfooterObjects2.length = 0;
gdjs.gameIntroCode.GDfooterObjects3.length = 0;
gdjs.gameIntroCode.GDfooterObjects4.length = 0;
gdjs.gameIntroCode.GDfooterObjects5.length = 0;
gdjs.gameIntroCode.GDbackgroundObjects1.length = 0;
gdjs.gameIntroCode.GDbackgroundObjects2.length = 0;
gdjs.gameIntroCode.GDbackgroundObjects3.length = 0;
gdjs.gameIntroCode.GDbackgroundObjects4.length = 0;
gdjs.gameIntroCode.GDbackgroundObjects5.length = 0;
gdjs.gameIntroCode.GDbackButtonObjects1.length = 0;
gdjs.gameIntroCode.GDbackButtonObjects2.length = 0;
gdjs.gameIntroCode.GDbackButtonObjects3.length = 0;
gdjs.gameIntroCode.GDbackButtonObjects4.length = 0;
gdjs.gameIntroCode.GDbackButtonObjects5.length = 0;
gdjs.gameIntroCode.GDpauseButtonObjects1.length = 0;
gdjs.gameIntroCode.GDpauseButtonObjects2.length = 0;
gdjs.gameIntroCode.GDpauseButtonObjects3.length = 0;
gdjs.gameIntroCode.GDpauseButtonObjects4.length = 0;
gdjs.gameIntroCode.GDpauseButtonObjects5.length = 0;
gdjs.gameIntroCode.GDstarHolderObjects1.length = 0;
gdjs.gameIntroCode.GDstarHolderObjects2.length = 0;
gdjs.gameIntroCode.GDstarHolderObjects3.length = 0;
gdjs.gameIntroCode.GDstarHolderObjects4.length = 0;
gdjs.gameIntroCode.GDstarHolderObjects5.length = 0;
gdjs.gameIntroCode.GDstar1Objects1.length = 0;
gdjs.gameIntroCode.GDstar1Objects2.length = 0;
gdjs.gameIntroCode.GDstar1Objects3.length = 0;
gdjs.gameIntroCode.GDstar1Objects4.length = 0;
gdjs.gameIntroCode.GDstar1Objects5.length = 0;
gdjs.gameIntroCode.GDstar2Objects1.length = 0;
gdjs.gameIntroCode.GDstar2Objects2.length = 0;
gdjs.gameIntroCode.GDstar2Objects3.length = 0;
gdjs.gameIntroCode.GDstar2Objects4.length = 0;
gdjs.gameIntroCode.GDstar2Objects5.length = 0;
gdjs.gameIntroCode.GDstar3Objects1.length = 0;
gdjs.gameIntroCode.GDstar3Objects2.length = 0;
gdjs.gameIntroCode.GDstar3Objects3.length = 0;
gdjs.gameIntroCode.GDstar3Objects4.length = 0;
gdjs.gameIntroCode.GDstar3Objects5.length = 0;
gdjs.gameIntroCode.GDcorrectWordTextObjects1.length = 0;
gdjs.gameIntroCode.GDcorrectWordTextObjects2.length = 0;
gdjs.gameIntroCode.GDcorrectWordTextObjects3.length = 0;
gdjs.gameIntroCode.GDcorrectWordTextObjects4.length = 0;
gdjs.gameIntroCode.GDcorrectWordTextObjects5.length = 0;
gdjs.gameIntroCode.GDanswersNeededTextObjects1.length = 0;
gdjs.gameIntroCode.GDanswersNeededTextObjects2.length = 0;
gdjs.gameIntroCode.GDanswersNeededTextObjects3.length = 0;
gdjs.gameIntroCode.GDanswersNeededTextObjects4.length = 0;
gdjs.gameIntroCode.GDanswersNeededTextObjects5.length = 0;
gdjs.gameIntroCode.GDpauseWordObjects1.length = 0;
gdjs.gameIntroCode.GDpauseWordObjects2.length = 0;
gdjs.gameIntroCode.GDpauseWordObjects3.length = 0;
gdjs.gameIntroCode.GDpauseWordObjects4.length = 0;
gdjs.gameIntroCode.GDpauseWordObjects5.length = 0;
gdjs.gameIntroCode.GDPauseScreenObjects1.length = 0;
gdjs.gameIntroCode.GDPauseScreenObjects2.length = 0;
gdjs.gameIntroCode.GDPauseScreenObjects3.length = 0;
gdjs.gameIntroCode.GDPauseScreenObjects4.length = 0;
gdjs.gameIntroCode.GDPauseScreenObjects5.length = 0;
gdjs.gameIntroCode.GDCloudObjects1.length = 0;
gdjs.gameIntroCode.GDCloudObjects2.length = 0;
gdjs.gameIntroCode.GDCloudObjects3.length = 0;
gdjs.gameIntroCode.GDCloudObjects4.length = 0;
gdjs.gameIntroCode.GDCloudObjects5.length = 0;
gdjs.gameIntroCode.GDLevelSixTimeObjects1.length = 0;
gdjs.gameIntroCode.GDLevelSixTimeObjects2.length = 0;
gdjs.gameIntroCode.GDLevelSixTimeObjects3.length = 0;
gdjs.gameIntroCode.GDLevelSixTimeObjects4.length = 0;
gdjs.gameIntroCode.GDLevelSixTimeObjects5.length = 0;
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects1.length = 0;
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects2.length = 0;
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects3.length = 0;
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects4.length = 0;
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects5.length = 0;
gdjs.gameIntroCode.GDquestionMarkObjects1.length = 0;
gdjs.gameIntroCode.GDquestionMarkObjects2.length = 0;
gdjs.gameIntroCode.GDquestionMarkObjects3.length = 0;
gdjs.gameIntroCode.GDquestionMarkObjects4.length = 0;
gdjs.gameIntroCode.GDquestionMarkObjects5.length = 0;

gdjs.gameIntroCode.eventsList26(runtimeScene);
gdjs.gameIntroCode.GDovalObjects1.length = 0;
gdjs.gameIntroCode.GDovalObjects2.length = 0;
gdjs.gameIntroCode.GDovalObjects3.length = 0;
gdjs.gameIntroCode.GDovalObjects4.length = 0;
gdjs.gameIntroCode.GDovalObjects5.length = 0;
gdjs.gameIntroCode.GDcircleObjects1.length = 0;
gdjs.gameIntroCode.GDcircleObjects2.length = 0;
gdjs.gameIntroCode.GDcircleObjects3.length = 0;
gdjs.gameIntroCode.GDcircleObjects4.length = 0;
gdjs.gameIntroCode.GDcircleObjects5.length = 0;
gdjs.gameIntroCode.GDforwardButtonObjects1.length = 0;
gdjs.gameIntroCode.GDforwardButtonObjects2.length = 0;
gdjs.gameIntroCode.GDforwardButtonObjects3.length = 0;
gdjs.gameIntroCode.GDforwardButtonObjects4.length = 0;
gdjs.gameIntroCode.GDforwardButtonObjects5.length = 0;
gdjs.gameIntroCode.GDgameTileObjects1.length = 0;
gdjs.gameIntroCode.GDgameTileObjects2.length = 0;
gdjs.gameIntroCode.GDgameTileObjects3.length = 0;
gdjs.gameIntroCode.GDgameTileObjects4.length = 0;
gdjs.gameIntroCode.GDgameTileObjects5.length = 0;
gdjs.gameIntroCode.GDsplatObjects1.length = 0;
gdjs.gameIntroCode.GDsplatObjects2.length = 0;
gdjs.gameIntroCode.GDsplatObjects3.length = 0;
gdjs.gameIntroCode.GDsplatObjects4.length = 0;
gdjs.gameIntroCode.GDsplatObjects5.length = 0;
gdjs.gameIntroCode.GDincorrectAnswerObjects1.length = 0;
gdjs.gameIntroCode.GDincorrectAnswerObjects2.length = 0;
gdjs.gameIntroCode.GDincorrectAnswerObjects3.length = 0;
gdjs.gameIntroCode.GDincorrectAnswerObjects4.length = 0;
gdjs.gameIntroCode.GDincorrectAnswerObjects5.length = 0;
gdjs.gameIntroCode.GDfooterObjects1.length = 0;
gdjs.gameIntroCode.GDfooterObjects2.length = 0;
gdjs.gameIntroCode.GDfooterObjects3.length = 0;
gdjs.gameIntroCode.GDfooterObjects4.length = 0;
gdjs.gameIntroCode.GDfooterObjects5.length = 0;
gdjs.gameIntroCode.GDbackgroundObjects1.length = 0;
gdjs.gameIntroCode.GDbackgroundObjects2.length = 0;
gdjs.gameIntroCode.GDbackgroundObjects3.length = 0;
gdjs.gameIntroCode.GDbackgroundObjects4.length = 0;
gdjs.gameIntroCode.GDbackgroundObjects5.length = 0;
gdjs.gameIntroCode.GDbackButtonObjects1.length = 0;
gdjs.gameIntroCode.GDbackButtonObjects2.length = 0;
gdjs.gameIntroCode.GDbackButtonObjects3.length = 0;
gdjs.gameIntroCode.GDbackButtonObjects4.length = 0;
gdjs.gameIntroCode.GDbackButtonObjects5.length = 0;
gdjs.gameIntroCode.GDpauseButtonObjects1.length = 0;
gdjs.gameIntroCode.GDpauseButtonObjects2.length = 0;
gdjs.gameIntroCode.GDpauseButtonObjects3.length = 0;
gdjs.gameIntroCode.GDpauseButtonObjects4.length = 0;
gdjs.gameIntroCode.GDpauseButtonObjects5.length = 0;
gdjs.gameIntroCode.GDstarHolderObjects1.length = 0;
gdjs.gameIntroCode.GDstarHolderObjects2.length = 0;
gdjs.gameIntroCode.GDstarHolderObjects3.length = 0;
gdjs.gameIntroCode.GDstarHolderObjects4.length = 0;
gdjs.gameIntroCode.GDstarHolderObjects5.length = 0;
gdjs.gameIntroCode.GDstar1Objects1.length = 0;
gdjs.gameIntroCode.GDstar1Objects2.length = 0;
gdjs.gameIntroCode.GDstar1Objects3.length = 0;
gdjs.gameIntroCode.GDstar1Objects4.length = 0;
gdjs.gameIntroCode.GDstar1Objects5.length = 0;
gdjs.gameIntroCode.GDstar2Objects1.length = 0;
gdjs.gameIntroCode.GDstar2Objects2.length = 0;
gdjs.gameIntroCode.GDstar2Objects3.length = 0;
gdjs.gameIntroCode.GDstar2Objects4.length = 0;
gdjs.gameIntroCode.GDstar2Objects5.length = 0;
gdjs.gameIntroCode.GDstar3Objects1.length = 0;
gdjs.gameIntroCode.GDstar3Objects2.length = 0;
gdjs.gameIntroCode.GDstar3Objects3.length = 0;
gdjs.gameIntroCode.GDstar3Objects4.length = 0;
gdjs.gameIntroCode.GDstar3Objects5.length = 0;
gdjs.gameIntroCode.GDcorrectWordTextObjects1.length = 0;
gdjs.gameIntroCode.GDcorrectWordTextObjects2.length = 0;
gdjs.gameIntroCode.GDcorrectWordTextObjects3.length = 0;
gdjs.gameIntroCode.GDcorrectWordTextObjects4.length = 0;
gdjs.gameIntroCode.GDcorrectWordTextObjects5.length = 0;
gdjs.gameIntroCode.GDanswersNeededTextObjects1.length = 0;
gdjs.gameIntroCode.GDanswersNeededTextObjects2.length = 0;
gdjs.gameIntroCode.GDanswersNeededTextObjects3.length = 0;
gdjs.gameIntroCode.GDanswersNeededTextObjects4.length = 0;
gdjs.gameIntroCode.GDanswersNeededTextObjects5.length = 0;
gdjs.gameIntroCode.GDpauseWordObjects1.length = 0;
gdjs.gameIntroCode.GDpauseWordObjects2.length = 0;
gdjs.gameIntroCode.GDpauseWordObjects3.length = 0;
gdjs.gameIntroCode.GDpauseWordObjects4.length = 0;
gdjs.gameIntroCode.GDpauseWordObjects5.length = 0;
gdjs.gameIntroCode.GDPauseScreenObjects1.length = 0;
gdjs.gameIntroCode.GDPauseScreenObjects2.length = 0;
gdjs.gameIntroCode.GDPauseScreenObjects3.length = 0;
gdjs.gameIntroCode.GDPauseScreenObjects4.length = 0;
gdjs.gameIntroCode.GDPauseScreenObjects5.length = 0;
gdjs.gameIntroCode.GDCloudObjects1.length = 0;
gdjs.gameIntroCode.GDCloudObjects2.length = 0;
gdjs.gameIntroCode.GDCloudObjects3.length = 0;
gdjs.gameIntroCode.GDCloudObjects4.length = 0;
gdjs.gameIntroCode.GDCloudObjects5.length = 0;
gdjs.gameIntroCode.GDLevelSixTimeObjects1.length = 0;
gdjs.gameIntroCode.GDLevelSixTimeObjects2.length = 0;
gdjs.gameIntroCode.GDLevelSixTimeObjects3.length = 0;
gdjs.gameIntroCode.GDLevelSixTimeObjects4.length = 0;
gdjs.gameIntroCode.GDLevelSixTimeObjects5.length = 0;
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects1.length = 0;
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects2.length = 0;
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects3.length = 0;
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects4.length = 0;
gdjs.gameIntroCode.GDLevelSixheaderTimerObjects5.length = 0;
gdjs.gameIntroCode.GDquestionMarkObjects1.length = 0;
gdjs.gameIntroCode.GDquestionMarkObjects2.length = 0;
gdjs.gameIntroCode.GDquestionMarkObjects3.length = 0;
gdjs.gameIntroCode.GDquestionMarkObjects4.length = 0;
gdjs.gameIntroCode.GDquestionMarkObjects5.length = 0;


return;

}

gdjs['gameIntroCode'] = gdjs.gameIntroCode;
