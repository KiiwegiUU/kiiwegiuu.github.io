gdjs.levelMenuScreenCode = {};
gdjs.levelMenuScreenCode.localVariables = [];
gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1= [];
gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects2= [];
gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects3= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects1= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects2= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects3= [];
gdjs.levelMenuScreenCode.GDstar18Objects1= [];
gdjs.levelMenuScreenCode.GDstar18Objects2= [];
gdjs.levelMenuScreenCode.GDstar18Objects3= [];
gdjs.levelMenuScreenCode.GDstar4Objects1= [];
gdjs.levelMenuScreenCode.GDstar4Objects2= [];
gdjs.levelMenuScreenCode.GDstar4Objects3= [];
gdjs.levelMenuScreenCode.GDstar5Objects1= [];
gdjs.levelMenuScreenCode.GDstar5Objects2= [];
gdjs.levelMenuScreenCode.GDstar5Objects3= [];
gdjs.levelMenuScreenCode.GDstar6Objects1= [];
gdjs.levelMenuScreenCode.GDstar6Objects2= [];
gdjs.levelMenuScreenCode.GDstar6Objects3= [];
gdjs.levelMenuScreenCode.GDstar7Objects1= [];
gdjs.levelMenuScreenCode.GDstar7Objects2= [];
gdjs.levelMenuScreenCode.GDstar7Objects3= [];
gdjs.levelMenuScreenCode.GDstar8Objects1= [];
gdjs.levelMenuScreenCode.GDstar8Objects2= [];
gdjs.levelMenuScreenCode.GDstar8Objects3= [];
gdjs.levelMenuScreenCode.GDstar9Objects1= [];
gdjs.levelMenuScreenCode.GDstar9Objects2= [];
gdjs.levelMenuScreenCode.GDstar9Objects3= [];
gdjs.levelMenuScreenCode.GDstar10Objects1= [];
gdjs.levelMenuScreenCode.GDstar10Objects2= [];
gdjs.levelMenuScreenCode.GDstar10Objects3= [];
gdjs.levelMenuScreenCode.GDstar11Objects1= [];
gdjs.levelMenuScreenCode.GDstar11Objects2= [];
gdjs.levelMenuScreenCode.GDstar11Objects3= [];
gdjs.levelMenuScreenCode.GDstar12Objects1= [];
gdjs.levelMenuScreenCode.GDstar12Objects2= [];
gdjs.levelMenuScreenCode.GDstar12Objects3= [];
gdjs.levelMenuScreenCode.GDstar13Objects1= [];
gdjs.levelMenuScreenCode.GDstar13Objects2= [];
gdjs.levelMenuScreenCode.GDstar13Objects3= [];
gdjs.levelMenuScreenCode.GDstar14Objects1= [];
gdjs.levelMenuScreenCode.GDstar14Objects2= [];
gdjs.levelMenuScreenCode.GDstar14Objects3= [];
gdjs.levelMenuScreenCode.GDstar15Objects1= [];
gdjs.levelMenuScreenCode.GDstar15Objects2= [];
gdjs.levelMenuScreenCode.GDstar15Objects3= [];
gdjs.levelMenuScreenCode.GDstar16Objects1= [];
gdjs.levelMenuScreenCode.GDstar16Objects2= [];
gdjs.levelMenuScreenCode.GDstar16Objects3= [];
gdjs.levelMenuScreenCode.GDstar17Objects1= [];
gdjs.levelMenuScreenCode.GDstar17Objects2= [];
gdjs.levelMenuScreenCode.GDstar17Objects3= [];
gdjs.levelMenuScreenCode.GDLevel_95951Objects1= [];
gdjs.levelMenuScreenCode.GDLevel_95951Objects2= [];
gdjs.levelMenuScreenCode.GDLevel_95951Objects3= [];
gdjs.levelMenuScreenCode.GDLevel_95952Objects1= [];
gdjs.levelMenuScreenCode.GDLevel_95952Objects2= [];
gdjs.levelMenuScreenCode.GDLevel_95952Objects3= [];
gdjs.levelMenuScreenCode.GDLevel_95953Objects1= [];
gdjs.levelMenuScreenCode.GDLevel_95953Objects2= [];
gdjs.levelMenuScreenCode.GDLevel_95953Objects3= [];
gdjs.levelMenuScreenCode.GDLevel_95954Objects1= [];
gdjs.levelMenuScreenCode.GDLevel_95954Objects2= [];
gdjs.levelMenuScreenCode.GDLevel_95954Objects3= [];
gdjs.levelMenuScreenCode.GDLevel_95955Objects1= [];
gdjs.levelMenuScreenCode.GDLevel_95955Objects2= [];
gdjs.levelMenuScreenCode.GDLevel_95955Objects3= [];
gdjs.levelMenuScreenCode.GDLevel_95956Objects1= [];
gdjs.levelMenuScreenCode.GDLevel_95956Objects2= [];
gdjs.levelMenuScreenCode.GDLevel_95956Objects3= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects1= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects2= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects3= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects1= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects2= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects3= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects1= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects2= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects3= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects1= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects2= [];
gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects3= [];
gdjs.levelMenuScreenCode.GDgameTileObjects1= [];
gdjs.levelMenuScreenCode.GDgameTileObjects2= [];
gdjs.levelMenuScreenCode.GDgameTileObjects3= [];
gdjs.levelMenuScreenCode.GDsplatObjects1= [];
gdjs.levelMenuScreenCode.GDsplatObjects2= [];
gdjs.levelMenuScreenCode.GDsplatObjects3= [];
gdjs.levelMenuScreenCode.GDincorrectAnswerObjects1= [];
gdjs.levelMenuScreenCode.GDincorrectAnswerObjects2= [];
gdjs.levelMenuScreenCode.GDincorrectAnswerObjects3= [];
gdjs.levelMenuScreenCode.GDfooterObjects1= [];
gdjs.levelMenuScreenCode.GDfooterObjects2= [];
gdjs.levelMenuScreenCode.GDfooterObjects3= [];
gdjs.levelMenuScreenCode.GDbackgroundObjects1= [];
gdjs.levelMenuScreenCode.GDbackgroundObjects2= [];
gdjs.levelMenuScreenCode.GDbackgroundObjects3= [];
gdjs.levelMenuScreenCode.GDbackButtonObjects1= [];
gdjs.levelMenuScreenCode.GDbackButtonObjects2= [];
gdjs.levelMenuScreenCode.GDbackButtonObjects3= [];
gdjs.levelMenuScreenCode.GDpauseButtonObjects1= [];
gdjs.levelMenuScreenCode.GDpauseButtonObjects2= [];
gdjs.levelMenuScreenCode.GDpauseButtonObjects3= [];
gdjs.levelMenuScreenCode.GDstarHolderObjects1= [];
gdjs.levelMenuScreenCode.GDstarHolderObjects2= [];
gdjs.levelMenuScreenCode.GDstarHolderObjects3= [];
gdjs.levelMenuScreenCode.GDstar1Objects1= [];
gdjs.levelMenuScreenCode.GDstar1Objects2= [];
gdjs.levelMenuScreenCode.GDstar1Objects3= [];
gdjs.levelMenuScreenCode.GDstar2Objects1= [];
gdjs.levelMenuScreenCode.GDstar2Objects2= [];
gdjs.levelMenuScreenCode.GDstar2Objects3= [];
gdjs.levelMenuScreenCode.GDstar3Objects1= [];
gdjs.levelMenuScreenCode.GDstar3Objects2= [];
gdjs.levelMenuScreenCode.GDstar3Objects3= [];
gdjs.levelMenuScreenCode.GDcorrectWordTextObjects1= [];
gdjs.levelMenuScreenCode.GDcorrectWordTextObjects2= [];
gdjs.levelMenuScreenCode.GDcorrectWordTextObjects3= [];
gdjs.levelMenuScreenCode.GDanswersNeededTextObjects1= [];
gdjs.levelMenuScreenCode.GDanswersNeededTextObjects2= [];
gdjs.levelMenuScreenCode.GDanswersNeededTextObjects3= [];
gdjs.levelMenuScreenCode.GDpauseWordObjects1= [];
gdjs.levelMenuScreenCode.GDpauseWordObjects2= [];
gdjs.levelMenuScreenCode.GDpauseWordObjects3= [];
gdjs.levelMenuScreenCode.GDPauseScreenObjects1= [];
gdjs.levelMenuScreenCode.GDPauseScreenObjects2= [];
gdjs.levelMenuScreenCode.GDPauseScreenObjects3= [];
gdjs.levelMenuScreenCode.GDCloudObjects1= [];
gdjs.levelMenuScreenCode.GDCloudObjects2= [];
gdjs.levelMenuScreenCode.GDCloudObjects3= [];
gdjs.levelMenuScreenCode.GDLevelSixTimeObjects1= [];
gdjs.levelMenuScreenCode.GDLevelSixTimeObjects2= [];
gdjs.levelMenuScreenCode.GDLevelSixTimeObjects3= [];
gdjs.levelMenuScreenCode.GDLevelSixheaderTimerObjects1= [];
gdjs.levelMenuScreenCode.GDLevelSixheaderTimerObjects2= [];
gdjs.levelMenuScreenCode.GDLevelSixheaderTimerObjects3= [];
gdjs.levelMenuScreenCode.GDquestionMarkObjects1= [];
gdjs.levelMenuScreenCode.GDquestionMarkObjects2= [];
gdjs.levelMenuScreenCode.GDquestionMarkObjects3= [];


gdjs.levelMenuScreenCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(27).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Level_2"), gdjs.levelMenuScreenCode.GDLevel_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("menuLevelBox2"), gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95952Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95952Objects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects2[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(28).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Level_3"), gdjs.levelMenuScreenCode.GDLevel_95953Objects2);
gdjs.copyArray(runtimeScene.getObjects("menuLevelBox3"), gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95953Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95953Objects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects2[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(29).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Level_4"), gdjs.levelMenuScreenCode.GDLevel_95954Objects2);
gdjs.copyArray(runtimeScene.getObjects("menuLevelBox4"), gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95954Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95954Objects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects2[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(30).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Level_5"), gdjs.levelMenuScreenCode.GDLevel_95955Objects2);
gdjs.copyArray(runtimeScene.getObjects("menuLevelBox5"), gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95955Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95955Objects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects2[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(31).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Level_6"), gdjs.levelMenuScreenCode.GDLevel_95956Objects1);
gdjs.copyArray(runtimeScene.getObjects("levelSixMenuBox"), gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95956Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95956Objects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


};gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDmenuLevelBox1Objects2Objects = Hashtable.newFrom({"menuLevelBox1": gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects2});
gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDmenuLevelBox2Objects2Objects = Hashtable.newFrom({"menuLevelBox2": gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects2});
gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDmenuLevelBox3Objects2Objects = Hashtable.newFrom({"menuLevelBox3": gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects2});
gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDmenuLevelBox4Objects2Objects = Hashtable.newFrom({"menuLevelBox4": gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects2});
gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDmenuLevelBox5Objects2Objects = Hashtable.newFrom({"menuLevelBox5": gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects2});
gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDlevelSixMenuBoxObjects1Objects = Hashtable.newFrom({"levelSixMenuBox": gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1});
gdjs.levelMenuScreenCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("menuLevelBox1"), gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDmenuLevelBox1Objects2Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelOne", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menuLevelBox2"), gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDmenuLevelBox2Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(27).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelTwo", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menuLevelBox3"), gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDmenuLevelBox3Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(28).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelThree", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menuLevelBox4"), gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDmenuLevelBox4Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(29).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelFour", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("menuLevelBox5"), gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDmenuLevelBox5Objects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(30).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelFive", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("levelSixMenuBox"), gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDlevelSixMenuBoxObjects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(31).getAsBoolean();
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelSix", false);
}}

}


};gdjs.levelMenuScreenCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(22).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star6"), gdjs.levelMenuScreenCode.GDstar6Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar6Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar6Objects2[i].hide(false);
}
}}

}


};gdjs.levelMenuScreenCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(22).getAsNumber() <= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star5"), gdjs.levelMenuScreenCode.GDstar5Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar5Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar5Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.levelMenuScreenCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.levelMenuScreenCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(23).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star9"), gdjs.levelMenuScreenCode.GDstar9Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar9Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar9Objects2[i].hide(false);
}
}}

}


};gdjs.levelMenuScreenCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(23).getAsNumber() <= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star8"), gdjs.levelMenuScreenCode.GDstar8Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar8Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar8Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.levelMenuScreenCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.levelMenuScreenCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(24).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star12"), gdjs.levelMenuScreenCode.GDstar12Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar12Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar12Objects2[i].hide(false);
}
}}

}


};gdjs.levelMenuScreenCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(24).getAsNumber() <= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star11"), gdjs.levelMenuScreenCode.GDstar11Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar11Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar11Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.levelMenuScreenCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.levelMenuScreenCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(25).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star15"), gdjs.levelMenuScreenCode.GDstar15Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar15Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar15Objects2[i].hide(false);
}
}}

}


};gdjs.levelMenuScreenCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(25).getAsNumber() <= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star14"), gdjs.levelMenuScreenCode.GDstar14Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar14Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar14Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.levelMenuScreenCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.levelMenuScreenCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(26).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star18"), gdjs.levelMenuScreenCode.GDstar18Objects1);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar18Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar18Objects1[i].hide(false);
}
}}

}


};gdjs.levelMenuScreenCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(26).getAsNumber() <= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star17"), gdjs.levelMenuScreenCode.GDstar17Objects1);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar17Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar17Objects1[i].hide(false);
}
}
{ //Subevents
gdjs.levelMenuScreenCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.levelMenuScreenCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(32).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(22).getAsNumber());
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(22).setNumber(runtimeScene.getGame().getVariables().getFromIndex(32).getAsNumber());
}{gdjs.evtTools.storage.writeNumberInJSONFile("gameProgress", "levelOneMaxStars", runtimeScene.getGame().getVariables().getFromIndex(22).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(22).getAsNumber() <= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star4"), gdjs.levelMenuScreenCode.GDstar4Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar4Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar4Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.levelMenuScreenCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(33).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(23).getAsNumber());
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(23).setNumber(runtimeScene.getGame().getVariables().getFromIndex(33).getAsNumber());
}{gdjs.evtTools.storage.writeNumberInJSONFile("gameProgress", "levelTwoMaxStars", runtimeScene.getGame().getVariables().getFromIndex(23).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(23).getAsNumber() <= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star7"), gdjs.levelMenuScreenCode.GDstar7Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar7Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar7Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.levelMenuScreenCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(34).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(24).getAsNumber());
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(24).setNumber(runtimeScene.getGame().getVariables().getFromIndex(34).getAsNumber());
}{gdjs.evtTools.storage.writeNumberInJSONFile("gameProgress", "levelThreeMaxStars", runtimeScene.getGame().getVariables().getFromIndex(24).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(24).getAsNumber() <= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star10"), gdjs.levelMenuScreenCode.GDstar10Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar10Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar10Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.levelMenuScreenCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(35).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(25).getAsNumber());
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(25).setNumber(runtimeScene.getGame().getVariables().getFromIndex(35).getAsNumber());
}{gdjs.evtTools.storage.writeNumberInJSONFile("gameProgress", "levelFourMaxStars", runtimeScene.getGame().getVariables().getFromIndex(25).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(25).getAsNumber() <= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star13"), gdjs.levelMenuScreenCode.GDstar13Objects2);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar13Objects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar13Objects2[i].hide(false);
}
}
{ //Subevents
gdjs.levelMenuScreenCode.eventsList9(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(36).getAsNumber() < runtimeScene.getGame().getVariables().getFromIndex(26).getAsNumber());
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(26).setNumber(runtimeScene.getGame().getVariables().getFromIndex(36).getAsNumber());
}{gdjs.evtTools.storage.writeNumberInJSONFile("gameProgress", "levelFiveMaxStars", runtimeScene.getGame().getVariables().getFromIndex(26).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(26).getAsNumber() <= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("star16"), gdjs.levelMenuScreenCode.GDstar16Objects1);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar16Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar16Objects1[i].hide(false);
}
}
{ //Subevents
gdjs.levelMenuScreenCode.eventsList11(runtimeScene);} //End of subevents
}

}


};gdjs.levelMenuScreenCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(37).getAsNumber() > runtimeScene.getGame().getVariables().getFromIndex(38).getAsNumber());
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(38).setNumber(runtimeScene.getGame().getVariables().getFromIndex(37).getAsNumber());
}{gdjs.evtTools.storage.writeNumberInJSONFile("gameProgress", "highestLevelSixTimer", runtimeScene.getGame().getVariables().getFromIndex(38).getAsNumber());
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("LevelSixTime"), gdjs.levelMenuScreenCode.GDLevelSixTimeObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(Math.floor(runtimeScene.getGame().getVariables().getFromIndex(38).getAsNumber() / 60));
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(Math.floor(runtimeScene.getGame().getVariables().getFromIndex(38).getAsNumber() - (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() * 60)));
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevelSixTimeObjects2.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevelSixTimeObjects2[i].setBBText(runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() < 10);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setString(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() + ":0" + runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() >= 10);
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setString(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() + ":" + runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}}

}


};gdjs.levelMenuScreenCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "levelOnePassed", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(27));
}{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "levelTwoPassed", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(28));
}{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "levelThreePassed", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(29));
}{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "levelFourPassed", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(30));
}{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "levelFivePassed", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(31));
}{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "highestLevelSixTimer", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(38));
}{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "levelOneMaxStars", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(22));
}{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "levelTwoMaxStars", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(23));
}{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "levelThreeMaxStars", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(24));
}{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "levelFourMaxStars", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(25));
}{gdjs.evtTools.storage.readNumberFromJSONFile("gameProgress", "levelFiveMaxStars", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(26));
}}

}


};gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDquestionMarkObjects1Objects = Hashtable.newFrom({"questionMark": gdjs.levelMenuScreenCode.GDquestionMarkObjects1});
gdjs.levelMenuScreenCode.eventsList15 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("LevelSixTime"), gdjs.levelMenuScreenCode.GDLevelSixTimeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Level_1"), gdjs.levelMenuScreenCode.GDLevel_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Level_2"), gdjs.levelMenuScreenCode.GDLevel_95952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Level_3"), gdjs.levelMenuScreenCode.GDLevel_95953Objects1);
gdjs.copyArray(runtimeScene.getObjects("Level_4"), gdjs.levelMenuScreenCode.GDLevel_95954Objects1);
gdjs.copyArray(runtimeScene.getObjects("Level_5"), gdjs.levelMenuScreenCode.GDLevel_95955Objects1);
gdjs.copyArray(runtimeScene.getObjects("Level_6"), gdjs.levelMenuScreenCode.GDLevel_95956Objects1);
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.levelMenuScreenCode.GDbackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("levelSixMenuBox"), gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("menuLevelBox1"), gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("menuLevelBox2"), gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("menuLevelBox3"), gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("menuLevelBox4"), gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects1);
gdjs.copyArray(runtimeScene.getObjects("menuLevelBox5"), gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects1);
gdjs.copyArray(runtimeScene.getObjects("star10"), gdjs.levelMenuScreenCode.GDstar10Objects1);
gdjs.copyArray(runtimeScene.getObjects("star11"), gdjs.levelMenuScreenCode.GDstar11Objects1);
gdjs.copyArray(runtimeScene.getObjects("star12"), gdjs.levelMenuScreenCode.GDstar12Objects1);
gdjs.copyArray(runtimeScene.getObjects("star13"), gdjs.levelMenuScreenCode.GDstar13Objects1);
gdjs.copyArray(runtimeScene.getObjects("star14"), gdjs.levelMenuScreenCode.GDstar14Objects1);
gdjs.copyArray(runtimeScene.getObjects("star15"), gdjs.levelMenuScreenCode.GDstar15Objects1);
gdjs.copyArray(runtimeScene.getObjects("star16"), gdjs.levelMenuScreenCode.GDstar16Objects1);
gdjs.copyArray(runtimeScene.getObjects("star17"), gdjs.levelMenuScreenCode.GDstar17Objects1);
gdjs.copyArray(runtimeScene.getObjects("star18"), gdjs.levelMenuScreenCode.GDstar18Objects1);
gdjs.copyArray(runtimeScene.getObjects("star4"), gdjs.levelMenuScreenCode.GDstar4Objects1);
gdjs.copyArray(runtimeScene.getObjects("star5"), gdjs.levelMenuScreenCode.GDstar5Objects1);
gdjs.copyArray(runtimeScene.getObjects("star6"), gdjs.levelMenuScreenCode.GDstar6Objects1);
gdjs.copyArray(runtimeScene.getObjects("star7"), gdjs.levelMenuScreenCode.GDstar7Objects1);
gdjs.copyArray(runtimeScene.getObjects("star8"), gdjs.levelMenuScreenCode.GDstar8Objects1);
gdjs.copyArray(runtimeScene.getObjects("star9"), gdjs.levelMenuScreenCode.GDstar9Objects1);
{for(var i = 0, len = gdjs.levelMenuScreenCode.GDbackgroundObjects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDbackgroundObjects1[i].getBehavior("Opacity").setOpacity(180);
}
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar18Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar18Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar5Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar5Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar4Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar4Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar6Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar6Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar13Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar13Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar15Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar15Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar14Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar14Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar12Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar12Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar11Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar11Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar16Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar16Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar10Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar10Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar17Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar17Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar9Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar9Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar8Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar8Objects1[i].hide();
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDstar7Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDstar7Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95951Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95951Objects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95952Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95952Objects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95953Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95953Objects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95954Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95954Objects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95955Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95955Objects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95956Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95956Objects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevelSixTimeObjects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevelSixTimeObjects1[i].getBehavior("Opacity").setOpacity(130);
}
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects1[i].getBehavior("Opacity").setOpacity(130);
}
for(var i = 0, len = gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects1[i].getBehavior("Opacity").setOpacity(130);
}
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDLevel_95951Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDLevel_95951Objects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects1.length ;i < len;++i) {
    gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects1[i].getBehavior("Opacity").setOpacity(255);
}
}{runtimeScene.getGame().getVariables().getFromIndex(40).setBoolean(false);
}{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 0);
}}

}


{


gdjs.levelMenuScreenCode.eventsList0(runtimeScene);
}


{


gdjs.levelMenuScreenCode.eventsList1(runtimeScene);
}


{


gdjs.levelMenuScreenCode.eventsList12(runtimeScene);
}


{


gdjs.levelMenuScreenCode.eventsList13(runtimeScene);
}


{


gdjs.levelMenuScreenCode.eventsList14(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("questionMark"), gdjs.levelMenuScreenCode.GDquestionMarkObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.levelMenuScreenCode.mapOfGDgdjs_9546levelMenuScreenCode_9546GDquestionMarkObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "gameIntro", false);
}{runtimeScene.getGame().getVariables().getFromIndex(40).setBoolean(true);
}}

}


};

gdjs.levelMenuScreenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1.length = 0;
gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects2.length = 0;
gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects3.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects1.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects2.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar18Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar18Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar18Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar4Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar4Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar4Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar5Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar5Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar5Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar6Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar6Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar6Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar7Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar7Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar7Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar8Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar8Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar8Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar9Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar9Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar9Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar10Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar10Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar10Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar11Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar11Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar11Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar12Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar12Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar12Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar13Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar13Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar13Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar14Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar14Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar14Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar15Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar15Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar15Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar16Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar16Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar16Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar17Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar17Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar17Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95951Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95951Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95951Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95952Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95952Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95952Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95953Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95953Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95953Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95954Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95954Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95954Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95955Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95955Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95955Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95956Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95956Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95956Objects3.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects1.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects2.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects3.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects1.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects2.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects3.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects1.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects2.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects3.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects1.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects2.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects3.length = 0;
gdjs.levelMenuScreenCode.GDgameTileObjects1.length = 0;
gdjs.levelMenuScreenCode.GDgameTileObjects2.length = 0;
gdjs.levelMenuScreenCode.GDgameTileObjects3.length = 0;
gdjs.levelMenuScreenCode.GDsplatObjects1.length = 0;
gdjs.levelMenuScreenCode.GDsplatObjects2.length = 0;
gdjs.levelMenuScreenCode.GDsplatObjects3.length = 0;
gdjs.levelMenuScreenCode.GDincorrectAnswerObjects1.length = 0;
gdjs.levelMenuScreenCode.GDincorrectAnswerObjects2.length = 0;
gdjs.levelMenuScreenCode.GDincorrectAnswerObjects3.length = 0;
gdjs.levelMenuScreenCode.GDfooterObjects1.length = 0;
gdjs.levelMenuScreenCode.GDfooterObjects2.length = 0;
gdjs.levelMenuScreenCode.GDfooterObjects3.length = 0;
gdjs.levelMenuScreenCode.GDbackgroundObjects1.length = 0;
gdjs.levelMenuScreenCode.GDbackgroundObjects2.length = 0;
gdjs.levelMenuScreenCode.GDbackgroundObjects3.length = 0;
gdjs.levelMenuScreenCode.GDbackButtonObjects1.length = 0;
gdjs.levelMenuScreenCode.GDbackButtonObjects2.length = 0;
gdjs.levelMenuScreenCode.GDbackButtonObjects3.length = 0;
gdjs.levelMenuScreenCode.GDpauseButtonObjects1.length = 0;
gdjs.levelMenuScreenCode.GDpauseButtonObjects2.length = 0;
gdjs.levelMenuScreenCode.GDpauseButtonObjects3.length = 0;
gdjs.levelMenuScreenCode.GDstarHolderObjects1.length = 0;
gdjs.levelMenuScreenCode.GDstarHolderObjects2.length = 0;
gdjs.levelMenuScreenCode.GDstarHolderObjects3.length = 0;
gdjs.levelMenuScreenCode.GDstar1Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar1Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar1Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar2Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar2Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar2Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar3Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar3Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar3Objects3.length = 0;
gdjs.levelMenuScreenCode.GDcorrectWordTextObjects1.length = 0;
gdjs.levelMenuScreenCode.GDcorrectWordTextObjects2.length = 0;
gdjs.levelMenuScreenCode.GDcorrectWordTextObjects3.length = 0;
gdjs.levelMenuScreenCode.GDanswersNeededTextObjects1.length = 0;
gdjs.levelMenuScreenCode.GDanswersNeededTextObjects2.length = 0;
gdjs.levelMenuScreenCode.GDanswersNeededTextObjects3.length = 0;
gdjs.levelMenuScreenCode.GDpauseWordObjects1.length = 0;
gdjs.levelMenuScreenCode.GDpauseWordObjects2.length = 0;
gdjs.levelMenuScreenCode.GDpauseWordObjects3.length = 0;
gdjs.levelMenuScreenCode.GDPauseScreenObjects1.length = 0;
gdjs.levelMenuScreenCode.GDPauseScreenObjects2.length = 0;
gdjs.levelMenuScreenCode.GDPauseScreenObjects3.length = 0;
gdjs.levelMenuScreenCode.GDCloudObjects1.length = 0;
gdjs.levelMenuScreenCode.GDCloudObjects2.length = 0;
gdjs.levelMenuScreenCode.GDCloudObjects3.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixTimeObjects1.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixTimeObjects2.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixTimeObjects3.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixheaderTimerObjects1.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixheaderTimerObjects2.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixheaderTimerObjects3.length = 0;
gdjs.levelMenuScreenCode.GDquestionMarkObjects1.length = 0;
gdjs.levelMenuScreenCode.GDquestionMarkObjects2.length = 0;
gdjs.levelMenuScreenCode.GDquestionMarkObjects3.length = 0;

gdjs.levelMenuScreenCode.eventsList15(runtimeScene);
gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects1.length = 0;
gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects2.length = 0;
gdjs.levelMenuScreenCode.GDlevelSixMenuBoxObjects3.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects1.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects2.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox1Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar18Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar18Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar18Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar4Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar4Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar4Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar5Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar5Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar5Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar6Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar6Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar6Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar7Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar7Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar7Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar8Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar8Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar8Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar9Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar9Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar9Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar10Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar10Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar10Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar11Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar11Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar11Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar12Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar12Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar12Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar13Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar13Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar13Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar14Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar14Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar14Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar15Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar15Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar15Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar16Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar16Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar16Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar17Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar17Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar17Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95951Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95951Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95951Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95952Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95952Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95952Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95953Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95953Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95953Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95954Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95954Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95954Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95955Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95955Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95955Objects3.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95956Objects1.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95956Objects2.length = 0;
gdjs.levelMenuScreenCode.GDLevel_95956Objects3.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects1.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects2.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox2Objects3.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects1.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects2.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox3Objects3.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects1.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects2.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox4Objects3.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects1.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects2.length = 0;
gdjs.levelMenuScreenCode.GDmenuLevelBox5Objects3.length = 0;
gdjs.levelMenuScreenCode.GDgameTileObjects1.length = 0;
gdjs.levelMenuScreenCode.GDgameTileObjects2.length = 0;
gdjs.levelMenuScreenCode.GDgameTileObjects3.length = 0;
gdjs.levelMenuScreenCode.GDsplatObjects1.length = 0;
gdjs.levelMenuScreenCode.GDsplatObjects2.length = 0;
gdjs.levelMenuScreenCode.GDsplatObjects3.length = 0;
gdjs.levelMenuScreenCode.GDincorrectAnswerObjects1.length = 0;
gdjs.levelMenuScreenCode.GDincorrectAnswerObjects2.length = 0;
gdjs.levelMenuScreenCode.GDincorrectAnswerObjects3.length = 0;
gdjs.levelMenuScreenCode.GDfooterObjects1.length = 0;
gdjs.levelMenuScreenCode.GDfooterObjects2.length = 0;
gdjs.levelMenuScreenCode.GDfooterObjects3.length = 0;
gdjs.levelMenuScreenCode.GDbackgroundObjects1.length = 0;
gdjs.levelMenuScreenCode.GDbackgroundObjects2.length = 0;
gdjs.levelMenuScreenCode.GDbackgroundObjects3.length = 0;
gdjs.levelMenuScreenCode.GDbackButtonObjects1.length = 0;
gdjs.levelMenuScreenCode.GDbackButtonObjects2.length = 0;
gdjs.levelMenuScreenCode.GDbackButtonObjects3.length = 0;
gdjs.levelMenuScreenCode.GDpauseButtonObjects1.length = 0;
gdjs.levelMenuScreenCode.GDpauseButtonObjects2.length = 0;
gdjs.levelMenuScreenCode.GDpauseButtonObjects3.length = 0;
gdjs.levelMenuScreenCode.GDstarHolderObjects1.length = 0;
gdjs.levelMenuScreenCode.GDstarHolderObjects2.length = 0;
gdjs.levelMenuScreenCode.GDstarHolderObjects3.length = 0;
gdjs.levelMenuScreenCode.GDstar1Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar1Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar1Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar2Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar2Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar2Objects3.length = 0;
gdjs.levelMenuScreenCode.GDstar3Objects1.length = 0;
gdjs.levelMenuScreenCode.GDstar3Objects2.length = 0;
gdjs.levelMenuScreenCode.GDstar3Objects3.length = 0;
gdjs.levelMenuScreenCode.GDcorrectWordTextObjects1.length = 0;
gdjs.levelMenuScreenCode.GDcorrectWordTextObjects2.length = 0;
gdjs.levelMenuScreenCode.GDcorrectWordTextObjects3.length = 0;
gdjs.levelMenuScreenCode.GDanswersNeededTextObjects1.length = 0;
gdjs.levelMenuScreenCode.GDanswersNeededTextObjects2.length = 0;
gdjs.levelMenuScreenCode.GDanswersNeededTextObjects3.length = 0;
gdjs.levelMenuScreenCode.GDpauseWordObjects1.length = 0;
gdjs.levelMenuScreenCode.GDpauseWordObjects2.length = 0;
gdjs.levelMenuScreenCode.GDpauseWordObjects3.length = 0;
gdjs.levelMenuScreenCode.GDPauseScreenObjects1.length = 0;
gdjs.levelMenuScreenCode.GDPauseScreenObjects2.length = 0;
gdjs.levelMenuScreenCode.GDPauseScreenObjects3.length = 0;
gdjs.levelMenuScreenCode.GDCloudObjects1.length = 0;
gdjs.levelMenuScreenCode.GDCloudObjects2.length = 0;
gdjs.levelMenuScreenCode.GDCloudObjects3.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixTimeObjects1.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixTimeObjects2.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixTimeObjects3.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixheaderTimerObjects1.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixheaderTimerObjects2.length = 0;
gdjs.levelMenuScreenCode.GDLevelSixheaderTimerObjects3.length = 0;
gdjs.levelMenuScreenCode.GDquestionMarkObjects1.length = 0;
gdjs.levelMenuScreenCode.GDquestionMarkObjects2.length = 0;
gdjs.levelMenuScreenCode.GDquestionMarkObjects3.length = 0;


return;

}

gdjs['levelMenuScreenCode'] = gdjs.levelMenuScreenCode;
