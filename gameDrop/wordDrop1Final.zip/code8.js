gdjs.levelFinishedScreenCode = {};
gdjs.levelFinishedScreenCode.localVariables = [];
gdjs.levelFinishedScreenCode.GDstar4Objects1= [];
gdjs.levelFinishedScreenCode.GDstar4Objects2= [];
gdjs.levelFinishedScreenCode.GDstar4Objects3= [];
gdjs.levelFinishedScreenCode.GDstar4Objects4= [];
gdjs.levelFinishedScreenCode.GDstar4Objects5= [];
gdjs.levelFinishedScreenCode.GDstar4Objects6= [];
gdjs.levelFinishedScreenCode.GDstar4Objects7= [];
gdjs.levelFinishedScreenCode.GDstar4Objects8= [];
gdjs.levelFinishedScreenCode.GDstar5Objects1= [];
gdjs.levelFinishedScreenCode.GDstar5Objects2= [];
gdjs.levelFinishedScreenCode.GDstar5Objects3= [];
gdjs.levelFinishedScreenCode.GDstar5Objects4= [];
gdjs.levelFinishedScreenCode.GDstar5Objects5= [];
gdjs.levelFinishedScreenCode.GDstar5Objects6= [];
gdjs.levelFinishedScreenCode.GDstar5Objects7= [];
gdjs.levelFinishedScreenCode.GDstar5Objects8= [];
gdjs.levelFinishedScreenCode.GDstar6Objects1= [];
gdjs.levelFinishedScreenCode.GDstar6Objects2= [];
gdjs.levelFinishedScreenCode.GDstar6Objects3= [];
gdjs.levelFinishedScreenCode.GDstar6Objects4= [];
gdjs.levelFinishedScreenCode.GDstar6Objects5= [];
gdjs.levelFinishedScreenCode.GDstar6Objects6= [];
gdjs.levelFinishedScreenCode.GDstar6Objects7= [];
gdjs.levelFinishedScreenCode.GDstar6Objects8= [];
gdjs.levelFinishedScreenCode.GDstar7Objects1= [];
gdjs.levelFinishedScreenCode.GDstar7Objects2= [];
gdjs.levelFinishedScreenCode.GDstar7Objects3= [];
gdjs.levelFinishedScreenCode.GDstar7Objects4= [];
gdjs.levelFinishedScreenCode.GDstar7Objects5= [];
gdjs.levelFinishedScreenCode.GDstar7Objects6= [];
gdjs.levelFinishedScreenCode.GDstar7Objects7= [];
gdjs.levelFinishedScreenCode.GDstar7Objects8= [];
gdjs.levelFinishedScreenCode.GDNewBBTextObjects1= [];
gdjs.levelFinishedScreenCode.GDNewBBTextObjects2= [];
gdjs.levelFinishedScreenCode.GDNewBBTextObjects3= [];
gdjs.levelFinishedScreenCode.GDNewBBTextObjects4= [];
gdjs.levelFinishedScreenCode.GDNewBBTextObjects5= [];
gdjs.levelFinishedScreenCode.GDNewBBTextObjects6= [];
gdjs.levelFinishedScreenCode.GDNewBBTextObjects7= [];
gdjs.levelFinishedScreenCode.GDNewBBTextObjects8= [];
gdjs.levelFinishedScreenCode.GDnextButtonObjects1= [];
gdjs.levelFinishedScreenCode.GDnextButtonObjects2= [];
gdjs.levelFinishedScreenCode.GDnextButtonObjects3= [];
gdjs.levelFinishedScreenCode.GDnextButtonObjects4= [];
gdjs.levelFinishedScreenCode.GDnextButtonObjects5= [];
gdjs.levelFinishedScreenCode.GDnextButtonObjects6= [];
gdjs.levelFinishedScreenCode.GDnextButtonObjects7= [];
gdjs.levelFinishedScreenCode.GDnextButtonObjects8= [];
gdjs.levelFinishedScreenCode.GDreplayButtonObjects1= [];
gdjs.levelFinishedScreenCode.GDreplayButtonObjects2= [];
gdjs.levelFinishedScreenCode.GDreplayButtonObjects3= [];
gdjs.levelFinishedScreenCode.GDreplayButtonObjects4= [];
gdjs.levelFinishedScreenCode.GDreplayButtonObjects5= [];
gdjs.levelFinishedScreenCode.GDreplayButtonObjects6= [];
gdjs.levelFinishedScreenCode.GDreplayButtonObjects7= [];
gdjs.levelFinishedScreenCode.GDreplayButtonObjects8= [];
gdjs.levelFinishedScreenCode.GDNewTextObjects1= [];
gdjs.levelFinishedScreenCode.GDNewTextObjects2= [];
gdjs.levelFinishedScreenCode.GDNewTextObjects3= [];
gdjs.levelFinishedScreenCode.GDNewTextObjects4= [];
gdjs.levelFinishedScreenCode.GDNewTextObjects5= [];
gdjs.levelFinishedScreenCode.GDNewTextObjects6= [];
gdjs.levelFinishedScreenCode.GDNewTextObjects7= [];
gdjs.levelFinishedScreenCode.GDNewTextObjects8= [];
gdjs.levelFinishedScreenCode.GDgameTileObjects1= [];
gdjs.levelFinishedScreenCode.GDgameTileObjects2= [];
gdjs.levelFinishedScreenCode.GDgameTileObjects3= [];
gdjs.levelFinishedScreenCode.GDgameTileObjects4= [];
gdjs.levelFinishedScreenCode.GDgameTileObjects5= [];
gdjs.levelFinishedScreenCode.GDgameTileObjects6= [];
gdjs.levelFinishedScreenCode.GDgameTileObjects7= [];
gdjs.levelFinishedScreenCode.GDgameTileObjects8= [];
gdjs.levelFinishedScreenCode.GDsplatObjects1= [];
gdjs.levelFinishedScreenCode.GDsplatObjects2= [];
gdjs.levelFinishedScreenCode.GDsplatObjects3= [];
gdjs.levelFinishedScreenCode.GDsplatObjects4= [];
gdjs.levelFinishedScreenCode.GDsplatObjects5= [];
gdjs.levelFinishedScreenCode.GDsplatObjects6= [];
gdjs.levelFinishedScreenCode.GDsplatObjects7= [];
gdjs.levelFinishedScreenCode.GDsplatObjects8= [];
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects1= [];
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects2= [];
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects3= [];
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects4= [];
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects5= [];
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects6= [];
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects7= [];
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects8= [];
gdjs.levelFinishedScreenCode.GDfooterObjects1= [];
gdjs.levelFinishedScreenCode.GDfooterObjects2= [];
gdjs.levelFinishedScreenCode.GDfooterObjects3= [];
gdjs.levelFinishedScreenCode.GDfooterObjects4= [];
gdjs.levelFinishedScreenCode.GDfooterObjects5= [];
gdjs.levelFinishedScreenCode.GDfooterObjects6= [];
gdjs.levelFinishedScreenCode.GDfooterObjects7= [];
gdjs.levelFinishedScreenCode.GDfooterObjects8= [];
gdjs.levelFinishedScreenCode.GDbackgroundObjects1= [];
gdjs.levelFinishedScreenCode.GDbackgroundObjects2= [];
gdjs.levelFinishedScreenCode.GDbackgroundObjects3= [];
gdjs.levelFinishedScreenCode.GDbackgroundObjects4= [];
gdjs.levelFinishedScreenCode.GDbackgroundObjects5= [];
gdjs.levelFinishedScreenCode.GDbackgroundObjects6= [];
gdjs.levelFinishedScreenCode.GDbackgroundObjects7= [];
gdjs.levelFinishedScreenCode.GDbackgroundObjects8= [];
gdjs.levelFinishedScreenCode.GDbackButtonObjects1= [];
gdjs.levelFinishedScreenCode.GDbackButtonObjects2= [];
gdjs.levelFinishedScreenCode.GDbackButtonObjects3= [];
gdjs.levelFinishedScreenCode.GDbackButtonObjects4= [];
gdjs.levelFinishedScreenCode.GDbackButtonObjects5= [];
gdjs.levelFinishedScreenCode.GDbackButtonObjects6= [];
gdjs.levelFinishedScreenCode.GDbackButtonObjects7= [];
gdjs.levelFinishedScreenCode.GDbackButtonObjects8= [];
gdjs.levelFinishedScreenCode.GDpauseButtonObjects1= [];
gdjs.levelFinishedScreenCode.GDpauseButtonObjects2= [];
gdjs.levelFinishedScreenCode.GDpauseButtonObjects3= [];
gdjs.levelFinishedScreenCode.GDpauseButtonObjects4= [];
gdjs.levelFinishedScreenCode.GDpauseButtonObjects5= [];
gdjs.levelFinishedScreenCode.GDpauseButtonObjects6= [];
gdjs.levelFinishedScreenCode.GDpauseButtonObjects7= [];
gdjs.levelFinishedScreenCode.GDpauseButtonObjects8= [];
gdjs.levelFinishedScreenCode.GDstarHolderObjects1= [];
gdjs.levelFinishedScreenCode.GDstarHolderObjects2= [];
gdjs.levelFinishedScreenCode.GDstarHolderObjects3= [];
gdjs.levelFinishedScreenCode.GDstarHolderObjects4= [];
gdjs.levelFinishedScreenCode.GDstarHolderObjects5= [];
gdjs.levelFinishedScreenCode.GDstarHolderObjects6= [];
gdjs.levelFinishedScreenCode.GDstarHolderObjects7= [];
gdjs.levelFinishedScreenCode.GDstarHolderObjects8= [];
gdjs.levelFinishedScreenCode.GDstar1Objects1= [];
gdjs.levelFinishedScreenCode.GDstar1Objects2= [];
gdjs.levelFinishedScreenCode.GDstar1Objects3= [];
gdjs.levelFinishedScreenCode.GDstar1Objects4= [];
gdjs.levelFinishedScreenCode.GDstar1Objects5= [];
gdjs.levelFinishedScreenCode.GDstar1Objects6= [];
gdjs.levelFinishedScreenCode.GDstar1Objects7= [];
gdjs.levelFinishedScreenCode.GDstar1Objects8= [];
gdjs.levelFinishedScreenCode.GDstar2Objects1= [];
gdjs.levelFinishedScreenCode.GDstar2Objects2= [];
gdjs.levelFinishedScreenCode.GDstar2Objects3= [];
gdjs.levelFinishedScreenCode.GDstar2Objects4= [];
gdjs.levelFinishedScreenCode.GDstar2Objects5= [];
gdjs.levelFinishedScreenCode.GDstar2Objects6= [];
gdjs.levelFinishedScreenCode.GDstar2Objects7= [];
gdjs.levelFinishedScreenCode.GDstar2Objects8= [];
gdjs.levelFinishedScreenCode.GDstar3Objects1= [];
gdjs.levelFinishedScreenCode.GDstar3Objects2= [];
gdjs.levelFinishedScreenCode.GDstar3Objects3= [];
gdjs.levelFinishedScreenCode.GDstar3Objects4= [];
gdjs.levelFinishedScreenCode.GDstar3Objects5= [];
gdjs.levelFinishedScreenCode.GDstar3Objects6= [];
gdjs.levelFinishedScreenCode.GDstar3Objects7= [];
gdjs.levelFinishedScreenCode.GDstar3Objects8= [];
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects1= [];
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects2= [];
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects3= [];
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects4= [];
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects5= [];
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects6= [];
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects7= [];
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects8= [];
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects1= [];
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects2= [];
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects3= [];
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects4= [];
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects5= [];
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects6= [];
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects7= [];
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects8= [];
gdjs.levelFinishedScreenCode.GDpauseWordObjects1= [];
gdjs.levelFinishedScreenCode.GDpauseWordObjects2= [];
gdjs.levelFinishedScreenCode.GDpauseWordObjects3= [];
gdjs.levelFinishedScreenCode.GDpauseWordObjects4= [];
gdjs.levelFinishedScreenCode.GDpauseWordObjects5= [];
gdjs.levelFinishedScreenCode.GDpauseWordObjects6= [];
gdjs.levelFinishedScreenCode.GDpauseWordObjects7= [];
gdjs.levelFinishedScreenCode.GDpauseWordObjects8= [];
gdjs.levelFinishedScreenCode.GDPauseScreenObjects1= [];
gdjs.levelFinishedScreenCode.GDPauseScreenObjects2= [];
gdjs.levelFinishedScreenCode.GDPauseScreenObjects3= [];
gdjs.levelFinishedScreenCode.GDPauseScreenObjects4= [];
gdjs.levelFinishedScreenCode.GDPauseScreenObjects5= [];
gdjs.levelFinishedScreenCode.GDPauseScreenObjects6= [];
gdjs.levelFinishedScreenCode.GDPauseScreenObjects7= [];
gdjs.levelFinishedScreenCode.GDPauseScreenObjects8= [];
gdjs.levelFinishedScreenCode.GDCloudObjects1= [];
gdjs.levelFinishedScreenCode.GDCloudObjects2= [];
gdjs.levelFinishedScreenCode.GDCloudObjects3= [];
gdjs.levelFinishedScreenCode.GDCloudObjects4= [];
gdjs.levelFinishedScreenCode.GDCloudObjects5= [];
gdjs.levelFinishedScreenCode.GDCloudObjects6= [];
gdjs.levelFinishedScreenCode.GDCloudObjects7= [];
gdjs.levelFinishedScreenCode.GDCloudObjects8= [];
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects1= [];
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects2= [];
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects3= [];
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects4= [];
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects5= [];
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects6= [];
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects7= [];
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects8= [];
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects1= [];
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects2= [];
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects3= [];
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects4= [];
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects5= [];
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects6= [];
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects7= [];
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects8= [];
gdjs.levelFinishedScreenCode.GDquestionMarkObjects1= [];
gdjs.levelFinishedScreenCode.GDquestionMarkObjects2= [];
gdjs.levelFinishedScreenCode.GDquestionMarkObjects3= [];
gdjs.levelFinishedScreenCode.GDquestionMarkObjects4= [];
gdjs.levelFinishedScreenCode.GDquestionMarkObjects5= [];
gdjs.levelFinishedScreenCode.GDquestionMarkObjects6= [];
gdjs.levelFinishedScreenCode.GDquestionMarkObjects7= [];
gdjs.levelFinishedScreenCode.GDquestionMarkObjects8= [];


gdjs.levelFinishedScreenCode.asyncCallback15138564 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
{gdjs.evtTools.sound.playSound(runtimeScene, "sandExplosion.mp3", false, 100, 1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.4, 0.2, 0.2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}gdjs.levelFinishedScreenCode.localVariables.length = 0;
}
gdjs.levelFinishedScreenCode.eventsList0 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelFinishedScreenCode.asyncCallback15138564(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelFinishedScreenCode.asyncCallback15138108 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("star7"), gdjs.levelFinishedScreenCode.GDstar7Objects7);

{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar7Objects7.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar7Objects7[i].hide(false);
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar7Objects7.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar7Objects7[i].getBehavior("Tween").addObjectScaleTween3("starShrink", 3.8, "easeInOutCirc", 0.5, false, false);
}
}
{ //Subevents
gdjs.levelFinishedScreenCode.eventsList0(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.levelFinishedScreenCode.localVariables.length = 0;
}
gdjs.levelFinishedScreenCode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
/* Don't save star7 as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelFinishedScreenCode.asyncCallback15138108(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelFinishedScreenCode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() <= 0);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.levelFinishedScreenCode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.levelFinishedScreenCode.asyncCallback15134252 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
{gdjs.evtTools.sound.playSound(runtimeScene, "sandExplosion.mp3", false, 100, 1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.4, 0.2, 0.2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.levelFinishedScreenCode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.levelFinishedScreenCode.localVariables.length = 0;
}
gdjs.levelFinishedScreenCode.eventsList3 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
/* Don't save star7 as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelFinishedScreenCode.asyncCallback15134252(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelFinishedScreenCode.asyncCallback15132404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("star6"), gdjs.levelFinishedScreenCode.GDstar6Objects5);

{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar6Objects5.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar6Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar6Objects5.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar6Objects5[i].getBehavior("Tween").addObjectScaleTween3("starShrink", 3.8, "easeInOutCirc", 0.5, false, false);
}
}
{ //Subevents
gdjs.levelFinishedScreenCode.eventsList3(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.levelFinishedScreenCode.localVariables.length = 0;
}
gdjs.levelFinishedScreenCode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
/* Don't save star6 as it will be provided by the parent asyncObjectsList. */
/* Don't save star7 as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelFinishedScreenCode.asyncCallback15132404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelFinishedScreenCode.eventsList5 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() <= 1);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.levelFinishedScreenCode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.levelFinishedScreenCode.asyncCallback15133580 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
{gdjs.evtTools.sound.playSound(runtimeScene, "sandExplosion.mp3", false, 100, 1);
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.4, 0.2, 0.2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
gdjs.levelFinishedScreenCode.eventsList5(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.levelFinishedScreenCode.localVariables.length = 0;
}
gdjs.levelFinishedScreenCode.eventsList6 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
/* Don't save star6 as it will be provided by the parent asyncObjectsList. */
/* Don't save star7 as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelFinishedScreenCode.asyncCallback15133580(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelFinishedScreenCode.asyncCallback15131948 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("star5"), gdjs.levelFinishedScreenCode.GDstar5Objects3);

{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar5Objects3.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar5Objects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar5Objects3.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar5Objects3[i].getBehavior("Tween").addObjectScaleTween3("starShrink", 3.8, "easeInOutCirc", 0.5, false, false);
}
}
{ //Subevents
gdjs.levelFinishedScreenCode.eventsList6(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.levelFinishedScreenCode.localVariables.length = 0;
}
gdjs.levelFinishedScreenCode.eventsList7 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
/* Don't save star5 as it will be provided by the parent asyncObjectsList. */
/* Don't save star6 as it will be provided by the parent asyncObjectsList. */
/* Don't save star7 as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.levelFinishedScreenCode.asyncCallback15131948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelFinishedScreenCode.eventsList8 = function(runtimeScene, asyncObjectsList) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() <= 2);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.levelFinishedScreenCode.eventsList7(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.levelFinishedScreenCode.asyncCallback15127988 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.levelFinishedScreenCode.GDNewTextObjects2);
{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDNewTextObjects2.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDNewTextObjects2[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(12).getAsString());
}
}
{ //Subevents
gdjs.levelFinishedScreenCode.eventsList8(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.levelFinishedScreenCode.localVariables.length = 0;
}
gdjs.levelFinishedScreenCode.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.levelFinishedScreenCode.localVariables);
for (const obj of gdjs.levelFinishedScreenCode.GDstar5Objects1) asyncObjectsList.addObject("star5", obj);
for (const obj of gdjs.levelFinishedScreenCode.GDstar6Objects1) asyncObjectsList.addObject("star6", obj);
for (const obj of gdjs.levelFinishedScreenCode.GDstar7Objects1) asyncObjectsList.addObject("star7", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.levelFinishedScreenCode.asyncCallback15127988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.levelFinishedScreenCode.mapOfGDgdjs_9546levelFinishedScreenCode_9546GDreplayButtonObjects1Objects = Hashtable.newFrom({"replayButton": gdjs.levelFinishedScreenCode.GDreplayButtonObjects1});
gdjs.levelFinishedScreenCode.mapOfGDgdjs_9546levelFinishedScreenCode_9546GDnextButtonObjects1Objects = Hashtable.newFrom({"nextButton": gdjs.levelFinishedScreenCode.GDnextButtonObjects1});
gdjs.levelFinishedScreenCode.mapOfGDgdjs_9546levelFinishedScreenCode_9546GDbackButtonObjects1Objects = Hashtable.newFrom({"backButton": gdjs.levelFinishedScreenCode.GDbackButtonObjects1});
gdjs.levelFinishedScreenCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewBBText"), gdjs.levelFinishedScreenCode.GDNewBBTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.levelFinishedScreenCode.GDbackgroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("star4"), gdjs.levelFinishedScreenCode.GDstar4Objects1);
gdjs.copyArray(runtimeScene.getObjects("star5"), gdjs.levelFinishedScreenCode.GDstar5Objects1);
gdjs.copyArray(runtimeScene.getObjects("star6"), gdjs.levelFinishedScreenCode.GDstar6Objects1);
gdjs.copyArray(runtimeScene.getObjects("star7"), gdjs.levelFinishedScreenCode.GDstar7Objects1);
{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDNewBBTextObjects1.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDNewBBTextObjects1[i].setBBText(runtimeScene.getGame().getVariables().getFromIndex(19).getAsString());
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar4Objects1.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar4Objects1[i].getBehavior("Opacity").setOpacity(130);
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDbackgroundObjects1.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDbackgroundObjects1[i].getBehavior("Opacity").setOpacity(180);
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar5Objects1.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar5Objects1[i].getBehavior("Scale").setScale(15);
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar6Objects1.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar6Objects1[i].getBehavior("Scale").setScale(15);
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar7Objects1.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar7Objects1[i].getBehavior("Scale").setScale(15);
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar5Objects1.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar5Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar6Objects1.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar6Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.levelFinishedScreenCode.GDstar7Objects1.length ;i < len;++i) {
    gdjs.levelFinishedScreenCode.GDstar7Objects1[i].hide();
}
}
{ //Subevents
gdjs.levelFinishedScreenCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("replayButton"), gdjs.levelFinishedScreenCode.GDreplayButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.levelFinishedScreenCode.mapOfGDgdjs_9546levelFinishedScreenCode_9546GDreplayButtonObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(20).getAsString(), false);
}{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("nextButton"), gdjs.levelFinishedScreenCode.GDnextButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.levelFinishedScreenCode.mapOfGDgdjs_9546levelFinishedScreenCode_9546GDnextButtonObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(21).getAsString(), false);
}{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.levelFinishedScreenCode.GDbackButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.levelFinishedScreenCode.mapOfGDgdjs_9546levelFinishedScreenCode_9546GDbackButtonObjects1Objects, runtimeScene, true, false);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelMenuScreen", false);
}{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(0);
}}

}


};

gdjs.levelFinishedScreenCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.levelFinishedScreenCode.GDstar4Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects8.length = 0;

gdjs.levelFinishedScreenCode.eventsList10(runtimeScene);
gdjs.levelFinishedScreenCode.GDstar4Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar4Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar5Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar6Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar7Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDNewBBTextObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDnextButtonObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDreplayButtonObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDNewTextObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDgameTileObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDsplatObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDincorrectAnswerObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDfooterObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDbackgroundObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDbackButtonObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDpauseButtonObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDstarHolderObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar1Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar2Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects1.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects2.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects3.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects4.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects5.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects6.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects7.length = 0;
gdjs.levelFinishedScreenCode.GDstar3Objects8.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDcorrectWordTextObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDanswersNeededTextObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDpauseWordObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDPauseScreenObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDCloudObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixTimeObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDLevelSixheaderTimerObjects8.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects1.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects2.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects3.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects4.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects5.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects6.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects7.length = 0;
gdjs.levelFinishedScreenCode.GDquestionMarkObjects8.length = 0;


return;

}

gdjs['levelFinishedScreenCode'] = gdjs.levelFinishedScreenCode;
